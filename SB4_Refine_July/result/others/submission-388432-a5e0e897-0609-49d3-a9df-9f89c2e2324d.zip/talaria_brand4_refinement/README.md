# Brand 4 Discovery

This project is to create the forecasting of Brand 4 products.

## Docker Instructions
`docker pull jupyter/datascience-notebook:latest`

`docker run --rm -p 10000:8888 -v "$PWD":/home/jovyan/work jupyter/datascience-notebook:latest`

Once logged into docker run ./install_packages.sh

## Directory structure and know how:

.
├── Privatized\ Data\ for\ Evaluation.xlsx
├── README.md
├── base_model_params
│   ├── lstm_scores_and_params.json
│   ├── regression_scores_and_params.json
│   └── sarimax_scores_and_params.json
├── codes
│   ├── Solution_exploration_smoothed.ipynb
│   ├── Wrapper.ipynb
│   ├── conf.py
│   ├── feature_preprocessing.py
│   ├── mape_raw_score_calculation.py
│   ├── model.py
│   ├── overall_training_and_inference.py
│   └── utils.py
├── ensemble_weights
│   ├── Falcon_ARPU_Existingregression_lstm_ensemble.dump
│   ├── Falcon_ARPU_Existingregression_sarimax_ensemble.dump
│   ├── Falcon_ARPU_Existingregression_sarimax_lstm_ensemble.dump
│   ├── Falcon_ARPU_Existingsarimax_lstm_ensemble.dump
│   ├── Falcon_ARPU_Newregression_lstm_ensemble.dump
│   ├── Falcon_ARPU_Newregression_sarimax_ensemble.dump
│   ├── Falcon_ARPU_Newregression_sarimax_lstm_ensemble.dump
│   ├── Falcon_ARPU_Newsarimax_lstm_ensemble.dump
│   ├── Falcon_Gross_Addsregression_lstm_ensemble.dump
│   ├── Falcon_Gross_Addsregression_sarimax_ensemble.dump
│   ├── Falcon_Gross_Addsregression_sarimax_lstm_ensemble.dump
│   ├── Falcon_Gross_Addssarimax_lstm_ensemble.dump
│   ├── Falcon_Net_Migrationregression_lstm_ensemble.dump
│   ├── Falcon_Net_Migrationregression_sarimax_ensemble.dump
│   ├── Falcon_Net_Migrationregression_sarimax_lstm_ensemble.dump
│   └── Falcon_Net_Migrationsarimax_lstm_ensemble.dump
├── install_packages.sh
├── output
│   └── sandesh_brand4_refinement_prediction_output.csv
└── robust
    ├── submission_1.csv
    ├── submission_10.csv
    ├── submission_11.csv
    ├── submission_12.csv
    ├── submission_2.csv
    ├── submission_3.csv
    ├── submission_4.csv
    ├── submission_5.csv
    ├── submission_6.csv
    ├── submission_7.csv
    ├── submission_8.csv
    └── submission_9.csv

Input file is xlsx file

In base_model_params directory the parameter for base models are stored. For creating the parameters, run ./codes/Solution_exploration_smoothed.ipynb. Copy the parameter dictionary as following:

    Copy the content of scores_and_params into regression_scores_and_params.json
    Copy the content of sarimax_scores_params into sarimax_scores_and_params.json
    Copy the content of lstm_scores_params into lstm_scores_and_params.json

In Code directory all the codes are there.
1. Solution_exploration_smoothed.ipynb - This notebook provides the explanation of the models and does the hyperparameter optimzation. Also as the end solution leverage ensemble, the model selection for each metrics are specified in this notebook. While creating the ensemble validation with the training data, ensemble weights are stored in ./ensemble_weights directory. The overall training process uses only data till 2019-09. This has been enforced in the initial steps for doing data smootihng. Data smoothing is also done to care of the outliers.
2. Wrapper.ipynb - This notebook is a wrapper notebook. The initial section predicts the metrices for 12 months since 2019-10. The output is then stored into ./output directory. And the later section derives the robustness forecast. Output of robustness forecast is stored under ./robust directory. There will be 12 files in this directory as we run robustness for 12 iterations. For robustmess calculation data beyond 2019-09 is used to check and print the MAPE errors only. It is not used for any training purpose. 
3. conf.py - This file provides the configuration of source file (.xlsx)
4. feature_preprocessing.py - This file provides the necessary feature preprocessing for enabling the regression model used in this solution. Specially the rolling aggregation and creation of statistical features.
5. mape_raw_score_calculation.py - This module is created to help calculate raw score and mape error from the ground truth and predicted data.
6. model.py - Regression model and Sarimax model code is written here
7. overall_training_and_inference.py - This file is used to do the overall training and inference for the forecsating window, using the hyperparameters created previously. This uses Regression, Sarimax and LSTM as base models. And then use ensemble methods. At the end the model selection method is used to map a metric with a model.
8. utils.py - some utility function such as outlier smoothing, rolling aggregation

In ensemble_weights directory the weights for each metrices corresponding to each ensemble models are stored

install_packages.sh - run this file from the docker instance in order to install the necessary packages which were not installed off-the-shelf in the docker image

In output directory the forecasted output can be found.

In robust directory the robustness outputs could be found.
