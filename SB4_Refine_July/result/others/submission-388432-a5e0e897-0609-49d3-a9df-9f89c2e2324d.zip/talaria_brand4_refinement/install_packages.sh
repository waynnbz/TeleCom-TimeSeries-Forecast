pip install --upgrade pip
pip install matrixprofile-ts
pip install catboost
pip install xgboost
pip install lightgbm
pip install tsfresh
pip install optuna
pip install tensorflow
pip install Keras
pip install holidays
