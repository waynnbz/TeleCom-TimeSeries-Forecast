import os
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from tqdm import tqdm_notebook as tqdm
import operator
import json
import datetime
from dateutil import relativedelta
import itertools

from pprint import pprint
from catboost import CatBoostRegressor
from xgboost import XGBRegressor
from xgboost import plot_importance
from sklearn.linear_model import Ridge, Lasso, LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import ParameterGrid
from sklearn.preprocessing import MinMaxScaler, StandardScaler

from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX


import conf

def process_train(train_piv):
    """
    Process train dataframe into useful format
    :param train_path: str, path to train data
    :return:
    """
    # create features
    storage = []

    # prev value
    temp = train_piv.copy()
    temp.columns = [f"{col}_prev_value" for col in train_piv.columns]
    storage.append(temp)

    # roll mean
    for rm in [2, 3, 6, 9, 12]:
        temp = train_piv.rolling(window=rm).mean()
        temp.columns = [f"{col}_roll_mean_{rm}" for col in train_piv.columns]
        storage.append(temp)

    # shift features
    for s in [1, 2, 3, 6, 12]:
        temp = train_piv.shift(s).copy()
        temp.columns = [f"{col}_shift_{s}" for col in train_piv.columns]
        storage.append(temp)

    # delta features
    for d in [1, 2, 3, 6, 12]:
        temp = (train_piv - train_piv.shift(d)).copy()
        temp.columns = [f"{col}_delta_{d}" for col in train_piv.columns]
        storage.append(temp)

    # combine features into single dataframe
    X = pd.concat(storage, axis=1)
    y = train_piv.loc[X.index]
    print("Data shape:", X.shape)
    return X, y


class Pipeline:
    def __init__(self, scale="MinMax", model="lr", train_points=12, diff=True):
        self.scale = None
        if scale == "MinMax":
            self.scale = MinMaxScaler()
        if scale == "Standard":
            self.scale = MinMaxScaler()

        # model
        self.model = None
        if model == "lr":
            self.model = Ridge(random_state=42)
        if model == "linear":
            self.model = LinearRegression()
        if model == "rf":
            self.model = RandomForestRegressor(n_estimators=120, random_state=42, n_jobs=-1)
        if model == "lasso":
            self.model = Lasso(alpha=100, random_state=42)
        if model == "catboost":
            self.model = CatBoostRegressor(learning_rate=0.05, n_estimators=10, silent=True)
        if model == "xgboost":
            self.model = XGBRegressor(learning_rate=0.05, n_estimators=20, silent=True)

        # select number points to train on
        self.train_points = train_points
        self.nanmissing = None
        self.diff = diff

    def fit(self, X_train, y_train):
        if self.diff:
            y_train = y_train.diff().dropna()
            X_train = X_train.loc[y_train.index].reset_index(drop=True)
            y_train = y_train.reset_index(drop=True)

        X_train, y_train = X_train[-self.train_points:], y_train[-self.train_points:]
        self.nanmissing = np.nanmean(X_train)
        X_train = X_train.fillna(self.nanmissing)
        X_train_scaled = self.scale.fit_transform(X_train)
        self.model.fit(X_train_scaled, y_train)
        
    def feature_importance(self, X_train):
        feature_importance_dict = dict(zip(X_train.columns, self.model.feature_importances_))
        feature_importance_dict = dict(sorted(feature_importance_dict.items(), key=operator.itemgetter(1), reverse=True)[:10])

        plt.bar(feature_importance_dict.keys(), feature_importance_dict.values())
        plt.xticks(rotation=90)
        plt.show()

    def predict(self, X_test, last_target_observation):
        X_test_temp = X_test.copy()
        X_test_temp = X_test_temp.fillna(self.nanmissing)
        X_test_scaled = self.scale.transform(X_test_temp)
        preds = self.model.predict(X_test_scaled)
        preds = np.array(preds)
        if self.diff:
            preds += last_target_observation
        return preds


def scoring(y_true, y_pred, eps=0.000001):
    """MAPE, %"""
    mape_ = abs((y_true - y_pred) / (y_true + eps))
    mape = np.mean(mape_) * 100
    return mape

def scoring_rmse(y_true, y_pred):
    rmse = np.sqrt(np.mean(np.square(y_true - y_pred)))
    return rmse

def raw_scoring(y_true, y_pred):
    mape_ = abs((y_true - y_pred)/y_true)
    raw = []
    for m in 1-mape_:
        if m > 0:
            raw_ = m
        else:
            raw_ = 0
            
        raw.append(raw_)
    
    return np.mean(raw)


def validate(X_train, y_train, validation_steps, pipelines=None):
    plot_feature_importance=conf.plot_feature_importance
    if pipelines is None:
        pipelines = [
            # LR
            {"train_points": 999, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 400, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 250, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 125, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 96, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 72, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 48, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 12, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 6, "scale": "MinMax", "model": "lr", "diff": True},
            {"train_points": 12, "scale": "Standard", "model": "lr", "diff": True},
            {"train_points": 48, "scale": "Standard", "model": "lr", "diff": True},
            {"train_points": 999, "scale": "Standard", "model": "lr", "diff": True},

            # LR
            {"train_points": 6, "scale": "MinMax", "model": "lr", "diff": False},
            {"train_points": 12, "scale": "MinMax", "model": "lr", "diff": False},
            {"train_points": 48, "scale": "MinMax", "model": "lr", "diff": False},
            {"train_points": 999, "scale": "MinMax", "model": "lr", "diff": False},
            {"train_points": 12, "scale": "Standard", "model": "lr", "diff": False},
            {"train_points": 48, "scale": "Standard", "model": "lr", "diff": False},
            {"train_points": 999, "scale": "Standard", "model": "lr", "diff": False},
            
            # linear
            {"train_points": 999, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 400, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 250, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 125, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 96, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 72, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 48, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 12, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 6, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 3, "scale": "MinMax", "model": "linear", "diff": True},
            {"train_points": 12, "scale": "Standard", "model": "linear", "diff": True},
            {"train_points": 48, "scale": "Standard", "model": "linear", "diff": True},
            {"train_points": 999, "scale": "Standard", "model": "linear", "diff": True},

            # linear
            {"train_points": 6, "scale": "MinMax", "model": "linear", "diff": False},
            {"train_points": 3, "scale": "MinMax", "model": "linear", "diff": False},
            {"train_points": 12, "scale": "MinMax", "model": "linear", "diff": False},
            {"train_points": 48, "scale": "MinMax", "model": "linear", "diff": False},
            {"train_points": 999, "scale": "MinMax", "model": "linear", "diff": False},
            {"train_points": 12, "scale": "Standard", "model": "linear", "diff": False},
            {"train_points": 48, "scale": "Standard", "model": "linear", "diff": False},
            {"train_points": 999, "scale": "Standard", "model": "linear", "diff": False},
            
            # catboost
            {"train_points": 999, "scale": "MinMax", "model": "catboost", "diff": True},
            {"train_points": 72, "scale": "MinMax", "model": "catboost", "diff": True},
            {"train_points": 48, "scale": "MinMax", "model": "catboost", "diff": True},
            {"train_points": 12, "scale": "MinMax", "model": "catboost", "diff": True},
            {"train_points": 6, "scale": "MinMax", "model": "catboost", "diff": True},

            # catboost
            {"train_points": 999, "scale": "MinMax", "model": "catboost", "diff": False},
            {"train_points": 72, "scale": "MinMax", "model": "catboost", "diff": False},
            {"train_points": 48, "scale": "MinMax", "model": "catboost", "diff": False},
            {"train_points": 12, "scale": "MinMax", "model": "catboost", "diff": False},
            {"train_points": 6, "scale": "MinMax", "model": "catboost", "diff": False},
            
            # xgboost
            {"train_points": 999, "scale": "MinMax", "model": "xgboost", "diff": True},
            {"train_points": 400, "scale": "MinMax", "model": "xgboost", "diff": True},
            {"train_points": 250, "scale": "MinMax", "model": "xgboost", "diff": True},
            {"train_points": 125, "scale": "MinMax", "model": "xgboost", "diff": True},
            {"train_points": 96, "scale": "MinMax", "model": "xgboost", "diff": True},
            {"train_points": 72, "scale": "MinMax", "model": "xgboost", "diff": True},
            {"train_points": 48, "scale": "MinMax", "model": "xgboost", "diff": True},
            {"train_points": 12, "scale": "MinMax", "model": "xgboost", "diff": True},
            {"train_points": 6, "scale": "MinMax", "model": "xgboost", "diff": True},

            # xgboost
            {"train_points": 999, "scale": "MinMax", "model": "xgboost", "diff": False},
            {"train_points": 72, "scale": "MinMax", "model": "xgboost", "diff": False},
            {"train_points": 48, "scale": "MinMax", "model": "xgboost", "diff": False},
            {"train_points": 12, "scale": "MinMax", "model": "xgboost", "diff": False},
            {"train_points": 6, "scale": "MinMax", "model": "xgboost", "diff": False},
        ]

    X_train_temp = X_train[:-validation_steps].copy().reset_index(drop=True)
    y_train_temp = y_train[:-validation_steps].copy().reset_index(drop=True)
    X_val_temp = X_train[-validation_steps:].copy().reset_index(drop=True)
    y_val_temp = y_train[-validation_steps:].copy().reset_index(drop=True)
    y_val_temp = np.array(y_val_temp)
    
    # find feature importance, if "True" in cofig file
    if plot_feature_importance :
        shift = 1
        y_to_predict = y_train_temp.shift(-shift).dropna()
        X_train_ = X_train_temp.loc[y_to_predict.index]
        X_train_ = X_train_.reset_index(drop=True)
        y_to_predict = y_to_predict.reset_index(drop=True)
        pipe = Pipeline(**{"train_points": 48, "scale": "MinMax", "model": "catboost", "diff": True})
        pipe.fit(X_train_, y_to_predict)
        
        imp_df = pd.DataFrame({})
        imp_df["importance"] = pipe.model.feature_importances_
        imp_df["features"] = X_train_.columns#pipe.model.feature_names_
        imp_df = imp_df.sort_values(by="importance", ascending=False).reset_index(drop=True)

        plt.bar(imp_df[:15]['features'], imp_df[:15]['importance'])
        plt.xticks(rotation=90)
        plt.show()

    results = {}
    for ind, pipeline_params in enumerate(pipelines):
        # calculate predictions for val data
        preds = []
        for step in range(validation_steps):
            shift = step + 1
            y_to_predict = y_train_temp.shift(-shift).dropna()
            X_train_ = X_train_temp.loc[y_to_predict.index]
            X_train_ = X_train_.reset_index(drop=True)
            y_to_predict = y_to_predict.reset_index(drop=True)

            pipe = Pipeline(**pipeline_params)
            pipe.fit(X_train_, y_to_predict)
            last_obs = list(y_train_temp[-1:])[0]

            X_test_temp = X_train_temp[-1:].copy()
            y_predicted = pipe.predict(X_test_temp, last_obs)[0]
            preds.append(y_predicted)

        # score pipelines
        preds = np.array(preds)
        score = scoring_rmse(y_val_temp, preds)
        mape_score = scoring(y_val_temp, preds)
        raw_score = raw_scoring(y_val_temp, preds)

        results[ind] = {
            "pipelines_params": pipeline_params,
            "val_preds":  preds,
            "rmse_score": score,
            "mape_score": mape_score,
            "raw_score": raw_score
        }

    best_params, best_val_score, best_val_preds,  best_val_mape= None, 0, None, np.inf
    for d in results.values():
        if d["raw_score"] > best_val_score:
            best_params = d["pipelines_params"]
            best_val_score = d["raw_score"]
            best_val_preds = d["val_preds"]
            best_val_mape = d["mape_score"]

    print("RAW score : ", best_val_score)
    print("MAPE score : ", best_val_mape)
    print("Best params : ")
    print(best_params)

    return best_params, best_val_score, best_val_mape, best_val_preds, y_val_temp


def refit_and_predict(X_train, y_train, best_params, horizon):
    preds = []
    for step in range(horizon):
        # prepare train data
        shift = step + 1
        y_to_predict = y_train.shift(-shift).dropna()
        X_train_ = X_train.loc[y_to_predict.index]
        X_train_ = X_train_.reset_index(drop=True)
        y_to_predict = y_to_predict.reset_index(drop=True)

        # refit with best params
        pipe = Pipeline(**best_params)
        pipe.fit(X_train_, y_to_predict)
        last_obs = list(y_train[-1:])[0]

        # make predictions
        y_predicted = pipe.predict(X_train[-1:], last_obs)[0]
        preds.append(y_predicted)

    return preds

def validate_arima(series, steps):
    """
    Iterates over possible values of p and d for ARIMA and finds the best as per validation MAPE.
    :param series: list, the list of variable values for which ARIMA parameters are to be determined
    """
    X = [x for x in series if not np.isnan(x)]
    train, test = X[:-steps], X[-steps:]
    min_score = 9999999
    final_p = final_d = None
    final_predictions = None
    print("here i am")
    # iterate through possible values for p and d and find MAPE on validation set
    for p in [0, 1, 2, 3]:
        for d in [0, 1, 2]:
            try:
                history = [x for x in train]
                predictions = list()
                for t in range(len(test)):
                    model = ARIMA(history, order=(p,d,0))
                    model_fit = model.fit(disp=0)
                    output = model_fit.forecast()
                    yhat = output[0]
                    predictions.append(yhat)
                    obs = test[t]
                    history.append(yhat)
#                     print('predicted=%f, expected=%f' % (yhat, obs))
                error = scoring_rmse(np.array(test), np.array(predictions))
                if error < min_score:
                    min_score = error
                    final_p = p
                    final_d = d
                    final_predictions = predictions
                  # uncomment below lines to see how predictions are comparing to actuals for validation set
                print('Test RMSE: %.3f' % error)
                plt.plot(test)
                plt.plot(predictions, color='red')
                plt.show()
            except:
                pass

    return final_predictions, final_p, final_d

def validate_sarimax (X_sarimax, steps):
    """
    Validate the best parameters for sarimax model

    """
    p = range(0,3)
    d = q = range(0,2)
    s = [3,6,12]
    pdq = list(itertools.product(p, d, q))
    seasonal_pdq = []
    for s_i in s:
        temp_s = [(x[0], x[1], x[2], s_i) for x in list(itertools.product(p, d, q))]
        seasonal_pdq.append(temp_s)
    seasonal_pdq = list(itertools.chain(*seasonal_pdq))
    result_param = -1
    result_param_seasonal = -1
    min_score = 0
    min_mape_score = 9999999
    for param in tqdm(pdq):
        for param_seasonal in seasonal_pdq:
            try:
                mod = SARIMAX(X_sarimax.iloc[:-steps,0],
                            # exog=X_sarimax.iloc[:-steps,1:],
                            order=param,
                            seasonal_order=param_seasonal,
                            enforce_stationarity=False,
                            enforce_invertibility=False
                            )
                result = mod.fit()
                start=len(X_sarimax.iloc[:-steps])
                end=len(X_sarimax.iloc[:-steps])+len(X_sarimax.iloc[-steps:])-1
                predictions = result.predict(start=start,
                                            end=end, 
                                            # exog=X_sarimax.iloc[-steps:,1:]
                                            )
                error = raw_scoring(X_sarimax.iloc[-steps:,0].values,predictions.values)
                mape_error = scoring(X_sarimax.iloc[-steps:,0].values,predictions.values)
                
                if error > min_score:
                    min_score = error
                    min_mape_score = mape_error
                    final_predictions = predictions
                    result_param = param
                    result_param_seasonal = param_seasonal
            except Exception as e:
                print("Error ", e)
                continue
    return min_score, min_mape_score, final_predictions, result_param, result_param_seasonal

def fit_and_predict_sarimax(X_sarimax, params, seasonal_params, predict_horizon=12):
    """
    This function will fit SARIMAX model with best parameters
    """
    mod = SARIMAX(X_sarimax.iloc[:, 0], \
        # exog=X_sarimax.iloc[:, 1:],
        order=params,
        seasonal_order=seasonal_params,
        enforce_stationarity=False,
        enforce_invertibility=False
        )
    result = mod.fit()
    start = len(X_sarimax)
    end = start+predict_horizon-1
    predictions = result.predict(start=start, \
        end=end, 
        # exog=exog_forecast,
        )
    return predictions

def fit_and_predict_arima(series, p, d, q, predict_horizon):
    """
    Fits and predicts values for the given variable.
    :param series: list, data to fit and predict on
    :param (p,d,q): tuple, p,d,q values for fitting ARIMA
    :param predict_horizon: int, predict horizon for targets
    """
    series = [x for x in series if not np.isnan(x)]
    history = series
    predictions = list()
    for t in range(predict_horizon):
        model = ARIMA(history, order=(p,d,q))
        model_fit = model.fit(disp=0)
        output = model_fit.forecast()
        yhat = output[0]
        predictions.append(yhat)
        history.append(yhat)
        
    return predictions
