import sys
import os
import pandas as pd
import numpy as np
import warnings
import itertools
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
warnings.filterwarnings("ignore")
from datetime import datetime
from dateutil import relativedelta
import json
import utils as utils
import conf as conf

from numpy.random import seed
seed(1)
import tensorflow as tf
tf.random.set_seed(10)

data = utils.get_dataframe()
# Get relevant columns and mould it into specific format further training and prediction
time_series_values_start = 9
X = np.array(data[data.columns[time_series_values_start:]].values)
X = X.T
X = pd.DataFrame(X)
X.columns = list(data["Generic LookupKey"])
X["time"] = data.columns[time_series_values_start:]
X = X.set_index("time")

## The columns which will be forecasted
cols_to_predict = list(X.columns.values)

## Dataframe is set as month start data
X.index.freq = 'MS'

## Take what is needed
X = X[cols_to_predict]


def scoring(y_true, y_pred, eps=0.000001):
    """MAPE, %"""
    mape_ = abs((y_true - y_pred) / (y_true + eps))
    mape = np.mean(mape_) * 100
    return mape

def raw_scoring(y_true, y_pred):
    mape_ = abs((y_true - y_pred)/y_true)
    raw = []
    
    for m in 1-mape_:
        
        if m > 0:
            raw_ = m
        else:
            raw_ = 0
            
        raw.append(raw_)
    
    return np.mean(raw)

def scoring_rmse(y_true, y_pred):
    rmse = np.sqrt(np.mean(np.square(y_true - y_pred)))
    return rmse


def calculate_scores(df_final_test_pred, forecast_start_date, forecast_end_date):

    gt_mape_candidate = X[forecast_start_date:forecast_end_date].copy()

    pred_mape_candidate_final = \
    df_final_test_pred[df_final_test_pred["Date"]<=\
    pd.to_datetime(forecast_end_date)].iloc[:,1:].copy() 
    print(pred_mape_candidate_final.shape)
    print(gt_mape_candidate.shape)
    for col in gt_mape_candidate.columns:
        mape_score = scoring(gt_mape_candidate.loc[:,col].values, pred_mape_candidate_final.loc[:,col].values)
        raw_score = raw_scoring(gt_mape_candidate.loc[:,col].values, pred_mape_candidate_final.loc[:,col].values)
        print(f'MAPE for column {col} is {mape_score} with Raw Score {raw_score}')
