import sys
import os
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")
import itertools
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
from sklearn.ensemble import IsolationForest
from datetime import datetime
from sklearn.preprocessing import MinMaxScaler
from matrixprofile import matrixProfile
from matrixprofile.discords import discords
import conf as conf

def get_dataframe(num_skiprows=2):
    data_basedir = conf.data_basedir
    data_path = os.path.join(data_basedir, conf.filename)
    brand_df = pd.read_excel(data_path, skiprows=num_skiprows)
    return brand_df

def mp_outlier_smoothing(temp_X, col, m=3, ex_zone=2, smoothing_window=2, num_anomalies=5, plot=True, random_state=22, verbose=True):
    """
    Outlier identification by matrixprofiling
    Smoothing by rolling window mean value
    """
    temp_X_col = temp_X[col].values
    profile = matrixProfile.stomp(temp_X_col,m)
    temp_X['profile'] = np.append(profile[0],np.zeros(m-1)+np.nan)
    temp_X['profile_index'] = np.append(profile[1], np.zeros(m - 1) + np.nan)

    anom = discords(temp_X['profile'],ex_zone=ex_zone, k=num_anomalies)

    X_rolling_mean = pd.Series(temp_X_col).rolling(smoothing_window).mean()

    X_smoothed = pd.Series(temp_X_col).copy()

    for i in range(len(temp_X[col])):
        if np.any(anom==i):
            X_smoothed[i] = X_rolling_mean[i]
    if verbose:
        print(f'Aomalies found at dates {temp_X.index.values[np.sort(anom)]}')
    if plot:
        plt.figure(figsize=(10,10))
        plt.plot(temp_X.index,pd.Series(temp_X_col),label='original')
        plt.legend()
        plt.show()
        plt.figure(figsize=(10,10))
        plt.plot(temp_X.index,temp_X['profile'],c='r',label='profile')
        plt.legend()
        plt.show()
        plt.figure(figsize=(10,10))
        plt.plot(temp_X.index,pd.Series(temp_X_col),c='b',label='Original')
        plt.plot(temp_X.index.values[anom],pd.Series(temp_X_col).values[anom],'X', c='r')
        plt.title('Outlier Finder')
        plt.legend()
        plt.show()
        plt.figure(figsize=(10,10))
        plt.plot(temp_X.index,pd.Series(temp_X_col),c='b',label='Original')
        plt.plot(temp_X.index,X_smoothed,c='g',label='Smoothed')
        plt.legend()
        plt.show()
    return X_smoothed




def outlier_smoothing(X, contamination=0.08, smoothing_window=3, \
center=True, min_periods=1, plot=False, random_state=22, verbose=True):
    """
    Outlier identification by IForest and 
    smoothing by rolling window median value
    """
    X_rolling_median = X.rolling(smoothing_window,\
    center=center,min_periods=min_periods).median()
    X_rolling_mean = X.rolling(smoothing_window,\
    center=center,min_periods=min_periods).mean()
    X_smoothing_ratio = X / X_rolling_median

    if plot:
        plt.figure(figsize=(10,10))
        plt.plot(X.index, X, label='original')
        plt.plot(X.index, X_rolling_median, label='rolling median')
        plt.title("Original vs. Rolling Median")
        plt.legend()
        plt.show()

        plt.figure(figsize=(10,10))
        plt.plot(X.index, X_smoothing_ratio, label="original:smoothing ratio")
        plt.title("Smoothing Ratio")
        plt.legend()
        plt.show()
    
    ## Find the outliers
    iso_forest = IsolationForest(contamination=contamination,\
        random_state=random_state)
    peaks = np.where(iso_forest.fit_predict(X_smoothing_ratio[smoothing_window-1:].\
        values.reshape(-1,1))<1)
    if verbose:
        print("Outliers found at ", X.index[peaks[0]+smoothing_window-1])
    if plot:
        plt.figure(figsize=(10,10))
        plt.plot(X.index, X, label='original')
        plt.plot(X.index.values[peaks[0]+smoothing_window-1],\
            X.values[peaks[0]+smoothing_window-1], 'x'
            )
        plt.title("Outlier Finders")
        plt.legend()
        plt.show()
    ## Change the outliers with corresponding smoothed values    
    X_smoothed = X.copy()

    for i in range(len(X)):
        if np.any(peaks[0]+smoothing_window-1==i):
            X_smoothed[i] = X_rolling_mean[i]

    if plot:
        plt.figure(figsize=(10,10))
        plt.plot(X.index, X, label='original')
        plt.plot(X.index, X_smoothed, label='smoothed')
        plt.title("Original vs. smoothed")
        plt.legend()
        plt.show()
    
    return X_smoothed

def fix_step_change(X, \
    step_change_date='2018-03-01',
    post_step_change_start='2018-04-01',
    corrected_step_max = '2018-05-01',
    verbose=True,
    plot=False
    ):
    """
    Fixing Step Change outlier
    """
    ## Plot before step change fix
    if plot:
        plt.figure(figsize=(10,10))
        plt.plot(X.index, X)
        plt.title("Raw value with step change outlier")
        plt.show()

    data_prior_step_change = X[:step_change_date]
    min_prior = min(data_prior_step_change)
    max_prior = max(data_prior_step_change)

    data_post_step_change = X[post_step_change_start:]
    min_post = min(data_post_step_change)
    max_post = max(data_post_step_change)

    avg_range = ((max_post-min_post)+(max_prior-min_prior))/2

    corrected_max_point = data_post_step_change[corrected_step_max]

    corrected_min_point = corrected_max_point - avg_range

    sc = MinMaxScaler(feature_range=(corrected_min_point, corrected_max_point))

    scaled_corrected_data = sc.fit_transform(data_prior_step_change.values.reshape(-1,1))

    corrected_prior_data = pd.Series(scaled_corrected_data.reshape(-1,))
    corrected_prior_data.index = data_prior_step_change.index

    corrected_data = pd.concat([corrected_prior_data, data_post_step_change])

    corrected_data.name = X.name

    if plot:
        plt.figure(figsize=(10,10))
        plt.plot(corrected_data.index, corrected_data)
        plt.title("Raw value after fixing step change outlier")
        plt.show()

    return corrected_data
