import sys
import os
import pandas as pd
import numpy as np
import warnings
import itertools
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
warnings.filterwarnings("ignore")
from datetime import datetime
from dateutil import relativedelta
import json
import utils as utils
import conf as conf



from numpy.random import seed
seed(1)
import tensorflow as tf
tf.random.set_seed(10)

def scoring(y_true, y_pred, eps=0.000001):
    """MAPE, %"""
    mape_ = abs((y_true - y_pred) / (y_true + eps))
    mape = np.mean(mape_) * 100
    return mape

def raw_scoring(y_true, y_pred):
    mape_ = abs((y_true - y_pred)/y_true)
    raw = []
    
    for m in 1-mape_:
        
        if m > 0:
            raw_ = m
        else:
            raw_ = 0
            
        raw.append(raw_)
    
    
    return np.mean(raw)

def scoring_rmse(y_true, y_pred):
    rmse = np.sqrt(np.mean(np.square(y_true - y_pred)))
    return rmse

def wrapper_train_inference(training_start_date,training_end_date,predict_horizon=12):
    data = utils.get_dataframe()
    # Get relevant columns and mould it into specific format further training and prediction
    time_series_values_start = 9
    X = np.array(data[data.columns[time_series_values_start:]].values)
    X = X.T
    X = pd.DataFrame(X)
    X.columns = list(data["Generic LookupKey"])
    X["time"] = data.columns[time_series_values_start:]
    X = X.set_index("time")

    ## The columns which will be forecasted
    cols_to_predict = list(X.columns.values)

    ## Dataframe is set as month start data
    X.index.freq = 'MS' 

    ## Take what is needed
    X = X[cols_to_predict]

    # Outlier Smoothing
    ## The columns which will not be smoothed
    excptn_2_smooth = []

    ## Step Outlier smoothing columns
    step_cols = ['Segment 2Sandesh Brand 1 / Sandesh Brand 2 - Segment 2BroadbandFalconAverage revenue per new customer - Falcon']  

    ## Outlier smoothing for regression done here
    smoothed_data = []
    for col in tqdm(cols_to_predict):
        print(col)
        temp_X = X[~X[col].isnull()]
        temp_X = temp_X[training_start_date:training_end_date]
        temp_X[col] = pd.to_numeric(temp_X[col])
        temp_X_col = temp_X[col]
        if np.any(np.array(step_cols)==col):
            # Implement first step change
            if training_end_date > '2018-09-01':
                temp_X_col = utils.fix_step_change(temp_X_col,
                                                step_change_date='2018-03-01',
                                                post_step_change_start='2018-04-01',
                                                corrected_step_max = '2018-09-01')
            # Implement second step change
            if training_end_date > '2019-07-01':
                temp_X_col = utils.fix_step_change(temp_X_col,
                                                step_change_date='2019-04-01',
                                                post_step_change_start='2019-05-01',
                                                corrected_step_max = '2019-07-01')
        if np.any(np.array(excptn_2_smooth)==col): 
            temp_X_smoothed = temp_X_col.copy()
        else:
            temp_X_smoothed = utils.outlier_smoothing(temp_X_col, contamination=0.6)
        
        smoothed_data.append(temp_X_smoothed)

    smoothed_data_df = pd.DataFrame(pd.concat(smoothed_data, axis=1).values, columns=cols_to_predict)

    smoothed_data_df.set_index(X[training_start_date:training_end_date].index.values, inplace=True)

    # Feature Engineering
    ## Import model
    import model as model
    import feature_preprocessing as feat_proc

    list_val_df = []
    for col in smoothed_data_df.columns:
        val = smoothed_data_df.reset_index().rename(columns={"index":"time"}).loc[:,["time",col]].values
        val_df = pd.DataFrame(val)
        val_df["metric"] = col
        list_val_df.append(val_df)

    smoothed_val_df_regr = \
    pd.concat(list_val_df).rename(columns={0:"time",
                                        1:"val"
                                        })

    smoothed_val_df_rolled = \
    feat_proc.get_rolling_dataframe(smoothed_val_df_regr,
                                    column_id="metric",
                                    column_sort="time",
                                    max_timeshift=3,
                                    min_timeshift=3,
                                    n_jobs=8
                                )

    smoothed_val_df_rolled_X = \
    feat_proc.get_features_dataframe(smoothed_val_df_rolled.drop("metric",axis=1),
                            column_id="id", column_sort="time", 
                            column_value="val",
                            fcparams="minimal"
                            )   

    smoothed_val_df_rolled_X["metric"] = \
    pd.Series(smoothed_val_df_rolled_X.index.values).\
    apply(lambda x: x.split(",")[0].split("=")[1]).values

    smoothed_val_df_rolled_X["timeshift_id"] = \
    pd.Series(smoothed_val_df_rolled_X.index.values).\
    apply(lambda x: x.split(",")[1].split("=")[1]).values

    smoothed_val_df_rolled_X.reset_index(drop=True, inplace=True)

    smoothed_val_df_rolled_X["timeshift_id"] = \
    pd.to_datetime(smoothed_val_df_rolled_X["timeshift_id"]).dt.date

    smoothed_val_df_regr["time"] = pd.to_datetime(smoothed_val_df_regr["time"]).dt.date

    smoothed_val_transformed_df = \
    pd.merge(smoothed_val_df_rolled_X,smoothed_val_df_regr,
                how="inner",
                right_on=["metric","time"],
                left_on=["metric","timeshift_id"]
                )

    smoothed_val_transformed_df["target_val"] = \
    smoothed_val_transformed_df.groupby("metric")["val"].shift(-1)

    smoothed_val_transformed_df.drop(["time","val"],axis=1,inplace=True)

    smoothed_val_transformed_df.dropna(inplace=True)


    ## Feature Engineered data starting from 2017-04-01
    X_eng, y = model.process_train(smoothed_data_df[training_start_date:])

    X_eng_price = X_eng.copy()
    # Training and Inference

    ## Validation steps
    VSTEPS = 6
    ## Set this to false if you don't want feature importance plotted
    plot_feature_importance = False

    predict_targets = cols_to_predict

    ## Regression
    df_val_true = pd.DataFrame({})
    df_val_pred = pd.DataFrame({})
    df_test_pred = pd.DataFrame({})

    ## Change the date values accordingly for different prediction date range
    df_test_pred['Date'] = \
    [datetime.date(datetime.strptime(training_end_date,"%Y-%m-%d")) + \
    relativedelta.relativedelta(months=i) for i in range(1, predict_horizon+1)]

    ## Prediction using Regression
    for col in tqdm(predict_targets):
        print(f"\n\nPredicting {col}")
        # select cols to use
        to_use = X_eng_price.columns
        y_train = y[col].copy()
        X_train = X_eng_price[to_use].copy()

        
        best_params = pd.read_json("../base_model_params/regression_scores_and_params.json")[col]["params"]
        test_preds = \
        model.refit_and_predict(X_train, y_train, best_params, horizon=predict_horizon)
        
        # df_val_pred[col] = val_preds
        # df_val_true[col] = val_true
        df_test_pred[col] = test_preds

    ## SARIMAX
    VSTEPS = 12

    # Outlier smoothing for SARIMAX
    smoothed_data = []
    for col in tqdm(cols_to_predict):
        print(col)
        temp_X = X[~X[col].isnull()]
        temp_X = temp_X[training_start_date:training_end_date]
        temp_X[col] = pd.to_numeric(temp_X[col])
        temp_X_col = temp_X[col]
        if np.any(np.array(step_cols)==col):
            # Implement first step change
            if training_end_date > '2018-09-01':
                temp_X_col = utils.fix_step_change(temp_X_col,
                                                step_change_date='2018-03-01',
                                                post_step_change_start='2018-04-01',
                                                corrected_step_max = '2018-09-01')
            # Implement second step change
            if training_end_date > '2019-07-01':
                temp_X_col = utils.fix_step_change(temp_X_col,
                                                step_change_date='2019-04-01',
                                                post_step_change_start='2019-05-01',
                                                corrected_step_max = '2019-07-01')
        if np.any(np.array(excptn_2_smooth)==col): 
            temp_X_smoothed = temp_X_col.copy()
        else:
            temp_X_smoothed = utils.outlier_smoothing(temp_X_col, contamination=0.45)
        
        smoothed_data.append(temp_X_smoothed)

    smoothed_data_df = pd.DataFrame(pd.concat(smoothed_data, axis=1).values, columns=cols_to_predict)

    smoothed_data_df.set_index(X[training_start_date:training_end_date].index.values, inplace=True)


    df_sarimax_val_true = pd.DataFrame({})
    df_sarimax_val_pred = pd.DataFrame({})
    df_sarimax_test_pred = pd.DataFrame({})

    ## Change the date values accordingly for different prediction date range
    df_sarimax_test_pred['Date'] = \
    [datetime.date(datetime.strptime(training_end_date,"%Y-%m-%d")) + \
    relativedelta.relativedelta(months=i) for i in range(1, predict_horizon+1)]


    ## SARIMAX prediction
    for col in tqdm(predict_targets):
        X_sarimax = smoothed_data_df[col][training_start_date:].copy()
        X_sarimax = pd.DataFrame(X_sarimax)
    #     print(pd.DataFrame(X_sarimax).iloc[:-5,0])
    #     pd.concat([smoothed_data_df[col]['2014-04-01':],
    #                price_increase_df['2014-04-01':]], axis=1)
    #     best_score, best_mape, val_prediction, best_params, best_param_seasonal = \
    #     model.validate_sarimax(X_sarimax, steps=VSTEPS)
        
    #     sarimax_scores_params[col] = {
    #             "raw_score": best_score,
    #             "mape_score": best_mape,
    #             "params": best_params,
    #             "seasonal_params": best_param_seasonal
    #         }
        best_params = pd.read_json("../base_model_params/sarimax_scores_and_params.json")[col]["params"]
        best_param_seasonal = pd.read_json("../base_model_params/sarimax_scores_and_params.json")[col]["seasonal_params"]
        test_predictions = model.fit_and_predict_sarimax(X_sarimax,
    #                                                      exog_forecast=\
    #                                                      forecast_price_increase_df,
                                                        params=best_params,
                                                        seasonal_params=best_param_seasonal,
                                                        predict_horizon=predict_horizon
                                                        )
        df_sarimax_test_pred[col] = test_predictions.values
    #     df_sarimax_val_pred[col] = val_prediction
    #     df_sarimax_val_true[col] = X_sarimax.iloc[-VSTEPS:,0]

    ## LSTM

    # Outlier smoothing for SARIMAX
    smoothed_data = []
    for col in tqdm(cols_to_predict):
        print(col)
        temp_X = X[~X[col].isnull()]
        temp_X = temp_X[training_start_date:training_end_date]
        temp_X[col] = pd.to_numeric(temp_X[col])
        temp_X_col = temp_X[col]
        if np.any(np.array(step_cols)==col):
            # Implement first step change
            if training_end_date > '2018-09-01':
                temp_X_col = utils.fix_step_change(temp_X_col,
                                                step_change_date='2018-03-01',
                                                post_step_change_start='2018-04-01',
                                                corrected_step_max = '2018-09-01')
            # Implement second step change
            if training_end_date > '2019-07-01':
                temp_X_col = utils.fix_step_change(temp_X_col,
                                                step_change_date='2019-04-01',
                                                post_step_change_start='2019-05-01',
                                                corrected_step_max = '2019-07-01')
        if np.any(np.array(excptn_2_smooth)==col): 
            temp_X_smoothed = temp_X_col.copy()
        else:
            temp_X_smoothed = utils.outlier_smoothing(temp_X_col, contamination=0.3)
        
        smoothed_data.append(temp_X_smoothed)

    smoothed_data_df = pd.DataFrame(pd.concat(smoothed_data, axis=1).values, columns=cols_to_predict)

    smoothed_data_df.set_index(X[training_start_date:training_end_date].index.values, inplace=True)


    def create_step_dataset(data, n_input, n_out):
        X, y = [], []

        in_start = 0
        
        data = pd.DataFrame(data)
        
        # step over the entire history one time step at a time
        for _ in range(len(data)):
            # define the end of the input sequence
            in_end = in_start + n_input
            out_end = in_end + n_out
            # ensure we have enough data for this instance 
            if out_end < len(data):
                X.append(data.iloc[in_start:in_end, :].values)
                y.append(data.iloc[in_end:out_end, 0].values)
                
            in_start += 1
        return np.array(X), np.array(y)

    ## Function for Model training

    from keras.models import Sequential
    from keras.layers import Dense
    from keras.layers import LSTM
    from keras.layers import Activation, Dropout
    from keras.layers import Flatten
    from keras.layers.convolutional import Conv1D
    from keras.layers.convolutional import MaxPooling1D
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import mean_squared_error
    from keras.layers import RepeatVector 
    from keras.layers import TimeDistributed 
    from keras.layers import ConvLSTM2D
    def train_LSTM_model(X, y, 
                        look_back, 
                        layer_1=64,
                        layer_2=32,
                        layer_3=16,
                        layer_4=8,
                        num_layers=4,
                        epochs=270, 
                        batch_size=6, 
                        verbose=10):
        lstm_model = Sequential()
        if num_layers==4:
            lstm_model.add(LSTM(layer_1, return_sequences= True, activation='relu', input_shape=( 1,look_back)))
            lstm_model.add(Dropout(0.15))
            lstm_model.add(LSTM(units=layer_2, activation='relu', return_sequences=True))
            lstm_model.add(Dropout(0.1))
            lstm_model.add(LSTM(units=layer_3, activation='relu', return_sequences=True))
            lstm_model.add(Dropout(0.05))
            lstm_model.add(LSTM(units=layer_4, activation='relu'))
        elif num_layers==3:
            lstm_model.add(LSTM(layer_1, return_sequences= True, activation='relu', input_shape=( 1,look_back)))
            lstm_model.add(Dropout(0.1))
            lstm_model.add(LSTM(units=layer_2, activation='relu', return_sequences=True))
            lstm_model.add(Dropout(0.05))
            lstm_model.add(LSTM(units=layer_3, activation='relu'))
        elif num_layers==2:
            lstm_model.add(LSTM(layer_1, return_sequences= True, activation='relu', input_shape=( 1,look_back)))
            lstm_model.add(Dropout(0.05))
            lstm_model.add(LSTM(units=layer_2, activation='relu'))
        lstm_model.add(Dense(1))
        lstm_model.compile(loss='mean_squared_error', optimizer='adam')
        lstm_model.fit(X, y, \
            epochs=epochs, 
            batch_size=batch_size, 
            verbose=verbose)
        return lstm_model


    ## Function for LSTM validation
    def validate_lstm(X_lstm, steps=VSTEPS, lookback=3):
        train_length = X_lstm.shape[0]-VSTEPS
        print(train_length)
        lstm_train_X, lstm_train_y = create_step_dataset(X_lstm[:train_length], lookback, 1)
    #     print(lstm_train_X.shape)
        lstm_train_X =\
        np.reshape(lstm_train_X, 
                (lstm_train_X.shape[0], 
                    lstm_train_X.shape[2], 
                    lstm_train_X.shape[1]))
        num_dims = lstm_train_X.shape[2]
        lstm_val_X, lstm_val_y = create_step_dataset(X_lstm[(train_length-lookback-1):], 
                                                    lookback, 1)
    #     print(lstm_val_X.shape)
        lstm_val_X =\
        np.reshape(lstm_val_X, 
                (lstm_val_X.shape[0], 
                    lstm_val_X.shape[2], 
                    lstm_val_X.shape[1]))
        
    #     print(lstm_train_X.shape, lstm_val_X.shape)
        epochs = [150]#np.arange(50,200,50)
        batches = [4] #np.arange(2,8,2)
        layers = [2,3,4]
        unit_configs = [(128,64,32,16),
                        (64,32,16,8),
                        (32,16,8,4)
                    ]
        min_mape_score = 9999
        min_score = -99
        result_params = {}
        try:
            for e in epochs:
                for b in batches:
                    for l in layers:
                        for u in unit_configs:
                            lstm_model = train_LSTM_model(lstm_train_X, 
                                                        lstm_train_y, 
                                                        look_back=lookback,
                                                        layer_1=u[0],
                                                        layer_2=u[1],
                                                        layer_3=u[2],
                                                        layer_4=u[3],
                                                        num_layers=l,
                                                        epochs=e,
                                                        batch_size=b,
                                                        verbose=False
                                                        )
                            mape_error = scoring(lstm_val_y, lstm_model.predict(lstm_val_X))
                            raw_error = raw_scoring(lstm_val_y, lstm_model.predict(lstm_val_X))
    #                         print(lstm_val_y)
    #                         print(lstm_model.predict(lstm_val_X))
    #                         print(lstm_model.predict(lstm_val_X).shape, lstm_val_y.shape)
    #                         print(raw_error)
    #                         print(min_score)
    #                         print(mape_error)
    #                         print(min_mape_score)
                            
        #                     print(f"orig: {lstm_val_y} and predict: {np.nan_to_num(lstm_model.predict(lstm_val_X))}")
        #                     print(f'RMSE {rmse_error} and min RMSE is {min_rmse_score}')
        #                     print(f'MAPE {mape_error} and min MAPE is {min_mape_score}')
    #                         or mape_error < min_mape_score
                            if raw_error > min_score :
                                
                                min_mape_score = mape_error
                                min_score = raw_error
                                final_prediction = lstm_model.predict(lstm_val_X)
                                result_params["epochs"] = e
                                result_params["batch_size"] = b
                                result_params["num_layers"] = l
                                result_params["unit_config"] = u
        except Exception as e:
            print(e)

        return min_mape_score, min_score, final_prediction, result_params    

    df_lstm_val_true = pd.DataFrame({})
    df_lstm_val_pred = pd.DataFrame({})
    df_lstm_test_pred = pd.DataFrame({})

    ## Change the date values accordingly for different prediction date range
    df_lstm_test_pred['Date'] = \
    [datetime.date(datetime.strptime(training_end_date,"%Y-%m-%d")) + \
    relativedelta.relativedelta(months=i) for i in range(1, predict_horizon+1)]

    ## Validate , Re-train and Predict for target horizon
    lstm_scores_params = {}
    lookback = 12
    for col in tqdm(predict_targets):
        print(col)
        X_lstm = smoothed_data_df[col][training_start_date:].copy()
    #     pd.concat([smoothed_data_df[col]['2017-04-01':],
    #                price_increase_df['2017-04-01':]], axis=1)
    #     best_mape_score, best_score, final_prediction, best_params = \
    #     validate_lstm(X_lstm, lookback=lookback)
    #     lstm_scores_params[col] = {
    #             "raw_score": best_score,
    #             "mape_score": best_mape_score,
    #             "params": best_params
    #         }
        
        ## create X and y in lstm input format for the specified column
        lstm_X, lstm_y = create_step_dataset(X_lstm, lookback, 1)
        
        lstm_X =\
        np.reshape(lstm_X, 
                (lstm_X.shape[0], 
                    1, 
                    lstm_X.shape[1]))
        
        best_params = pd.read_json("../base_model_params/lstm_scores_and_params.json")[col]["params"]
        
        ## Re-Train the model with best params
        lstm_model = train_LSTM_model(lstm_X, 
                                    lstm_y, 
                                    look_back=lookback,
                                    layer_1=best_params["unit_config"][0],
                                    layer_2=best_params["unit_config"][1],
                                    layer_3=best_params["unit_config"][2],
                                    layer_4=best_params["unit_config"][3],
                                    num_layers=best_params["num_layers"],
                                    epochs=best_params["epochs"],
                                    batch_size=best_params["batch_size"]
                                    )
        
        ## Prediction of future using retrained model
        lstm_prediction = []
        index = len(X_lstm)
        forecast_price_index = 0
        prediction_y = np.array([-99])
        for _ in range(predict_horizon):
            
            if prediction_y.reshape(1)[0] == -99:
                prediction_x = \
                X_lstm.iloc[index-lookback:].values
            if prediction_y.reshape(1)[0] != -99:
    #             new_pred_row = np.hstack([prediction_y.reshape(1)[0],
    #                                       forecast_price_increase_df.\
    #                                       iloc[forecast_price_index].values])
                new_pred_row = prediction_y.reshape(1)[0]

                prediction_x = np.hstack([prediction_x.reshape(-1)[1:], new_pred_row])
            
            prediction_x = \
            prediction_x.reshape(-1,1,lookback)

            prediction_y = lstm_model.predict(prediction_x)
            lstm_prediction.append(prediction_y.reshape(1)[0])
            index += 1
            forecast_price_index += 1
            
    #     df_lstm_val_pred[col] = final_prediction.reshape(-1)
        df_lstm_test_pred[col] = lstm_prediction


    ## Ensemble
    from sklearn.svm import SVR
    import joblib
    def col_mapping(col):
        if col == 'Segment 2Sandesh Brand 1 / Sandesh Brand 2 - Segment 2BroadbandFalconAverage revenue per new customer - Falcon':
            col_short = 'Falcon_ARPU_New'
        elif col == 'Segment 2Sandesh Brand 1 / Sandesh Brand 2 - Segment 2BroadbandFalconAverage revenue per existing customer - Falcon':
            col_short = 'Falcon_ARPU_Existing'
        elif col == 'Segment 2Sandesh Brand 1 / Sandesh Brand 2 - Segment 2BroadbandFalconGross Adds - Falcon(Norm)':
            col_short = 'Falcon_Gross_Adds'
        else:
            col_short = 'Falcon_Net_Migration'
        return col_short
    ## Doing stacked ensemble using Support Vector Machine regression
    regression_sarimax_score_params = {}
    df_ensemble_test_pred = pd.DataFrame({})
    for i in tqdm(range(df_sarimax_test_pred.iloc[:,1:].shape[1])):
        col = df_sarimax_test_pred.columns.values[i+1]
        clf = joblib.load("../ensemble_weights/"+col_mapping(col)+"regression_sarimax_ensemble.dump")
        X_test = pd.concat([df_sarimax_test_pred.iloc[:,i+1].reset_index(drop=True),
                    df_test_pred.iloc[:,i+1].reset_index(drop=True)], 
                    axis=1).values
        y_test = clf.predict(X_test)
        if np.any(excptn_2_smooth==col):
            df_ensemble_test_pred[col] = df_sarimax_test_pred[col]
        else:
            df_ensemble_test_pred[col] = y_test

    df_ensemble_test_pred.index = df_sarimax_test_pred["Date"]
    df_ensemble_test_pred.reset_index(inplace=True)
    df_regression_sarimax_test_pred = df_ensemble_test_pred.copy()

    ## Doing stacked ensemble using Support Vector Machine regression
    regression_sarimax_lstm_score_params = {}
    df_ensemble_test_pred = pd.DataFrame({})
    for i in tqdm(range(df_sarimax_test_pred.iloc[:,1:].shape[1])):
        col = df_sarimax_test_pred.columns.values[i+1]
        
        clf = joblib.load("../ensemble_weights/"+col_mapping(col)+"regression_sarimax_lstm_ensemble.dump")
        X_test = pd.concat([df_sarimax_test_pred.iloc[:,i+1].reset_index(drop=True),
                    df_test_pred.iloc[:,i+1].reset_index(drop=True),
                            df_lstm_test_pred.iloc[:,i+1].reset_index(drop=True)
                        ], 
                    axis=1).values
        y_test = clf.predict(X_test)
        
        df_ensemble_test_pred[col] = y_test

    df_ensemble_test_pred.index = df_sarimax_test_pred["Date"]
    df_ensemble_test_pred.reset_index(inplace=True)
    df_regression_sarimax_lstm_test_pred = df_ensemble_test_pred.copy()

    ## Doing stacked ensemble using Support Vector Machine regression
    sarimax_lstm_score_params = {}
    df_ensemble_test_pred = pd.DataFrame({})
    for i in tqdm(range(df_sarimax_test_pred.iloc[:,1:].shape[1])):
        col = df_sarimax_test_pred.columns.values[i+1]
        
        clf = joblib.load("../ensemble_weights/"+col_mapping(col)+"sarimax_lstm_ensemble.dump")
        X_test = pd.concat([df_sarimax_test_pred.iloc[:,i+1].reset_index(drop=True),
    #                    df_test_pred.iloc[:,i+1].reset_index(drop=True),
                            df_lstm_test_pred.iloc[:,i+1].reset_index(drop=True)
                        ], 
                    axis=1).values
        y_test = clf.predict(X_test)
        
        df_ensemble_test_pred[col] = y_test
        
    #     if np.any(excptn_2_smooth==col):
    #         df_ensemble_test_pred[col] = df_sarimax_test_pred[col]
    #     else:
    #         df_ensemble_test_pred[col] = y_test

    df_ensemble_test_pred.index = df_sarimax_test_pred["Date"]
    df_ensemble_test_pred.reset_index(inplace=True)
    df_sarimax_lstm_test_pred = df_ensemble_test_pred.copy()

    ## Doing stacked ensemble using Support Vector Machine regression
    regression_lstm_score_params = {}
    df_ensemble_test_pred = pd.DataFrame({})
    for i in tqdm(range(df_sarimax_test_pred.iloc[:,1:].shape[1])):
        col = df_sarimax_test_pred.columns.values[i+1]
        
        clf = joblib.load("../ensemble_weights/"+col_mapping(col)+"regression_lstm_ensemble.dump")
        X_test = pd.concat([
                    df_test_pred.iloc[:,i+1].reset_index(drop=True),
    #                     df_sarimax_test_pred.iloc[:,i+1].reset_index(drop=True),
                            df_lstm_test_pred.iloc[:,i+1].reset_index(drop=True)
                        ], 
                    axis=1).values
        y_test = clf.predict(X_test)
        
        df_ensemble_test_pred[col] = y_test
        
    #     if np.any(excptn_2_smooth==col):
    #         df_ensemble_test_pred[col] = df_sarimax_test_pred[col]
    #     else:
    #         df_ensemble_test_pred[col] = y_test

    df_ensemble_test_pred.index = df_sarimax_test_pred["Date"]
    df_ensemble_test_pred.reset_index(inplace=True)
    df_regression_lstm_test_pred = df_ensemble_test_pred.copy()

    ## Final Model Mapping
    final_model_mapping = {}
    final_model_mapping['Segment 2Sandesh Brand 1 / Sandesh Brand 2 - Segment 2BroadbandFalconAverage revenue per new customer - Falcon'] = "sarimax"
    final_model_mapping['Segment 2Sandesh Brand 1 / Sandesh Brand 2 - Segment 2BroadbandFalconAverage revenue per existing customer - Falcon'] = "sarimax"
    final_model_mapping['Segment 2Sandesh Brand 1 / Sandesh Brand 2 - Segment 2BroadbandFalconGross Adds - Falcon(Norm)'] = "sarimax_lstm"
    final_model_mapping['Segment 2Sandesh Brand 1 / Sandesh Brand 2 - Segment 2BroadbandFalconNet Migrations - Falcon(Norm)'] = "regression"
    
    df_final_test_pred = pd.DataFrame({})
    df_final_test_pred['Date'] = \
    [datetime.date(datetime.strptime(training_end_date,"%Y-%m-%d")) + \
    relativedelta.relativedelta(months=i) for i in range(1, predict_horizon+1)]

    for col in df_regression_lstm_test_pred.columns.values[1:]:
        model_name = final_model_mapping[col]
        if model_name == "regression":
            df_final_test_pred[col]=df_test_pred[col].values
        elif model_name == "sarimax":
            df_final_test_pred[col]=df_sarimax_test_pred[col].values
        elif model_name == "regression_sarimax":
            df_final_test_pred[col]=df_regression_sarimax_test_pred[col].values
        elif model_name == "lstm":
            df_final_test_pred[col]=df_lstm_test_pred[col].values
        elif model_name == "regression_sarimax_lstm":
            df_final_test_pred[col]=df_regression_sarimax_lstm_test_pred[col].values
        elif model_name == "sarimax_lstm":
            df_final_test_pred[col]=df_sarimax_lstm_test_pred[col].values
        elif model_name == "regression_lstm":
            df_final_test_pred[col]=df_regression_lstm_test_pred[col].values
        else:
            df_final_test_pred[col]=0

    return df_final_test_pred