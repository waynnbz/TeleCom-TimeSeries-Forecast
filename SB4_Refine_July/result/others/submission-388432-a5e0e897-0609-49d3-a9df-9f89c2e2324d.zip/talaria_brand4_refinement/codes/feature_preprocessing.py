import os
import numpy as np
import pandas as pd
from tsfresh.feature_extraction import extract_features, EfficientFCParameters, MinimalFCParameters
from tsfresh.utilities.dataframe_functions import roll_time_series, make_forecasting_frame
from tsfresh.utilities.dataframe_functions import impute

def get_agg_dataframe(df, cols_list, metric, operation="sum"):
    """
    Get aggregated dataframe if needed
    """
    if operation=="sum":
        df_agg = df.groupby(by=cols_list, as_index=False)[metric].sum()
    else:
        df_agg = None
    return df_agg

def get_rolling_dataframe(df, column_id, column_sort, max_timeshift=6, min_timeshift=6, n_jobs=8):
    """
    Get rolling window dataframe
    """
    df_rolled = roll_time_series(df, column_id=column_id,\
    column_sort=column_sort, max_timeshift= max_timeshift,\
    min_timeshift=min_timeshift, n_jobs=n_jobs
    )
    return df_rolled

def get_features_dataframe(df, column_id, column_sort, column_value, fcparams="minimal", n_jobs=8):
    """
    Extract features from dataframe
    """
    if fcparams=="minimal":
        df_X = extract_features(df, default_fc_parameters=MinimalFCParameters(),\
        column_id=column_id, column_sort=column_sort, column_value=column_value,\
        n_jobs=n_jobs, impute_function=impute, show_warnings=False
        )
    elif fcparams=="efficient":
        df_X = extract_features(df, default_fc_parameters=EfficientFCParameters(),\
        column_id=column_id, column_sort=column_sort, column_value=column_value,\
        n_jobs=n_jobs, impute_function=impute, show_warnings=False
        )
    else:
        df_X = None

    return df_X
