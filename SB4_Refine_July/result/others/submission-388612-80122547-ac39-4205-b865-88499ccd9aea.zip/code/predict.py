import argparse
import warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from Helper import *
import statsmodels.api as sm


def predict_on(training_end = -6,predict_month = 12,save_to='prediction.csv'):
    # read data
    data = pd.read_excel('../data/Privatized Data for Evaluation.xlsx')
    # create empty output date frame with date
    predict_month_start = data.iloc[1,training_end]
    month_strs =get_all_future_dates(predict_month_start)
    output_df = pd.DataFrame({'Time Period':month_strs})

    # ARPU new
    index = 8
    values = data.iloc[index,9:]
    train_data = data.iloc[index,-24:training_end]
    for i in range(12):
        train_data = correct_linear(train_data)
    predict_data = list(predict_linear(train_data,predict_month = 5))
    for i in range(6):
        predict_data.append(predict_data[-1])
    key_name = data.iloc[index,7]
    output_df[key_name] = predict_data

    # ARPU old
    index = 9
    values = data.iloc[index,9:]
    train_data = data.iloc[index,training_end-6:training_end]
    predict_data = list(predict_linear(train_data,predict_month = 5))
    for i in range(6):
        predict_data.append(predict_data[-1])
    key_name = data.iloc[index,7]
    output_df[key_name] = predict_data
    # Gross Adds
    index =15
    ## prepare and split data 
    values = data.iloc[index,9:]
    train_data = values[training_end-12:training_end]
    train_d = [float(x) for x in train_data.values]
    ## model
    mod = sm.tsa.statespace.SARIMAX(train_d, trend='t', order=(0,0,2))
    res = mod.fit(disp=False)
    prediction_data =res.predict(start = 0,end=11)
    key_name = data.iloc[index,7]
    output_df[key_name] = prediction_data


    # Net Mig
    index = 17
    ## prepare and split data 
    true_y = data.iloc[index,9 :].values
    true_x = np.zeros((true_y.shape[0],18))
    new_index = 0
    for i in range(2,20):# all 10 features 
        true_x[:,new_index]= data.iloc[i,9:].values
        new_index +=1
    train_y = true_y[6:training_end]
    train_x = true_x[:training_end - 6,:]
    test_x = true_x[training_end - 6:training_end,:]
    ## model
    prediction_data = predict_leavers(train_x,train_y,test_x,learning_rate = 0.1,round_n = 500)
    key_name = data.iloc[index,7]
    output_df[key_name] = prediction_data
    # output
    output_df[key_name] = prediction_data
    output_df.to_csv(save_to,index = False)

def main(args):
    period = 12
    if args.period:
        period = int(args.period)
    iterations = 6
    if args.iteration:
        iterations = int(args.iteration)

    # prediction file
    predict_on(training_end = -6,predict_month = period,save_to='../prediction.csv')
    # robust
    start_month = -12
    if args.start_date:
        start_month = int(args.start_date)

    for i in range(1,iterations+1):
        predict_on(training_end = start_month-i,predict_month =period,save_to='../robust/submission' + str(i)+'.csv')


   


parser = argparse.ArgumentParser()
parser.add_argument("-start_date")
parser.add_argument("-end_date")
parser.add_argument("-period")
parser.add_argument("-iteration")
input_c = parser.parse_args()
main(input_c)
