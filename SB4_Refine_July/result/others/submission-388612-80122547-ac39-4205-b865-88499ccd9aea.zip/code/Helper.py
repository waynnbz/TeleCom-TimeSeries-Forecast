################################################################################
#
# by thothling
#
#   1, given a date '2019-09', output 12 month's date  ['2019-10' ... '2020-09']
#   2, linear fit & remove outliners
#   3,
#
################################################################################
import warnings
warnings.filterwarnings("ignore")
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression
import lightgbm as lgb
from datetime import datetime
from dateutil.relativedelta import relativedelta


# return 12 date ['2019-10' ... '2020-09']
def get_all_future_dates(first_date):
    first_date = datetime.strptime(str(first_date), '%Y-%m-%d %H:%M:%S')
    all_predict_months = [first_date]
    for i in range(1,12):
        new_date = first_date+  relativedelta(months=i)
        all_predict_months.append(new_date)
    month_str =[]
    for a_date in all_predict_months:
        if a_date.month < 10:
            month_str.append (str(a_date.year)+'-0'+str(a_date.month))
        else:
            month_str.append (str(a_date.year)+'-'+str(a_date.month))
    #print ('predict month = ')
    #print (month_str)
    return month_str


# caculate MAPE score
def caculate_score(predict_data,real_data):
    mape_values = []
    for i in range(len(real_data)):
        pred = predict_data[i]
        gt = real_data[i]
        mape_values.append(abs(pred-gt)/abs(gt))
    score = np.mean(mape_values)
    print (score)
    plt.plot(predict_data)
    plt.plot(real_data,'r')



# remove abnormal values for linear fit
def correct_linear(all_values):
    all_index = np.array(list(range(len(all_values)))).reshape(-1, 1)
    model=LinearRegression()
    model.fit(all_index,all_values)
    predict_value = model.predict(all_index)
    max_error_index = -1 
    max_error = 0
    for i in range(len(predict_value)):
        the_error = abs(predict_value[i] - all_values[i])
        if the_error > max_error:
            max_error = the_error
            max_error_index = i
    new_values = []
    for i in range(len(predict_value)):
        if i == max_error_index:
            new_values.append(predict_value[i])
        else:
            new_values.append(all_values[i])
    return new_values

# linear fit
def predict_linear(all_values,predict_month = 6):
    all_index = np.array(list(range(len(all_values)))).reshape(-1, 1)
    all_index2 = np.array(list(range(len(all_values),len(all_values)+predict_month+1))).reshape(-1, 1)
    model=LinearRegression()
    model.fit(all_index,all_values)
    predict_value = model.predict(all_index2)
    return predict_value


def predict_closing_6month(value_series,fit_error=False):
    predict_month = 6
    df =pd.DataFrame({
        'index':list(range(len(value_series))),
        'value':value_series
        })
    df['mean']= df['value'].rolling(predict_month).mean()
    #
    #
    future_mean = df['mean'][-1*predict_month:]
    future_mean = np.array(future_mean)
    past_mean = df['mean'][predict_month:-1*predict_month]
    df = df.iloc[2*predict_month:]
    #
    df['mean'] = past_mean.values
    df['error'] = df['value'] - df['mean']
    if not fit_error:
        future_values =[x+np.mean(df['error']) for x in future_mean]
        return future_values
    else:
        new_error = correct_linear(df['error'].values.reshape(-1, 1))
        df['new_error'] =[x[0] for x in new_error]
        new_error = correct_linear(df['new_error'].values.reshape(-1, 1))
        df['new_error'] =[x[0] for x in new_error]
        new_error = correct_linear(df['new_error'].values.reshape(-1, 1))
        df['new_error'] =[x[0] for x in new_error]
        new_error = predict_linear(df['new_error'].values.reshape(-1,1),predict_month = predict_month)
        #
        fix_values = []
        for i in range(predict_month):
            fix_values.append(future_mean[i] +new_error[i][0])
        return fix_values

def predict_closing_12month(value_series,fit_error=False):
    predict_data= predict_closing_6month(value_series,fit_error)
    value_series = list(value_series)
    value_series.extend(predict_data)
    future_12month= predict_closing_6month(value_series,fit_error)
    predict_data.extend(future_12month)
    return predict_data


def predict_leavers(train_x,train_y,test_x,learning_rate = 0.001,round_n = 2):
    train_data = lgb.Dataset(train_x, label=train_y)
    print (train_x.shape)
    print (train_y.shape)
    print (train_data)
    param = {'num_leaves': 5, 'objective': 'regression','learning_rate': learning_rate,"min_child_samples": 5}
    param['metric'] = 'mape'
    bst = lgb.train(param, train_data, num_boost_round=round_n)
    predicts  = bst.predict(test_x)
    predicts = list(predicts)
    for i in range(6):
        predicts.append(predicts[-1])
    return predicts