# Talaria Forecasting - Financial Forecast BB Sandesh Brand 4 - Refinement

## Requirements

- Python 3.6 (at least)

## Install libs
d
```console
~$ pip install xlrd numpy pandas statsmodels lightgbm scikit-learn lightgbm matplotlib
```

## Running the app
```console
~$ python .\predict.py
```

it will automatically create 7 files:
-	1 prediction file in ../prediction.csv
-   6 robust file in ../robust/

### You could also use commond 
```console
~$ python .\predict.py -start_date=-12 -period=12 -iteration=6
```

#### Please ignore the ConvergenceWarning, SARIMAX created these warnings, it can't be removed because the factors are fixed.