# CFO Forecasting - Financial Forecast BB Sandesh Brand 4 - Refinement
Deployment Guide

## Description
- Implements a neural network based approach to forecasting product performance based on historical data

## Project Structure
```
.
├── config.json - Stores the dataset information and model hyperparameters (already optimized for the provided dataset)
├── dataset
│   └── Mobile_Sandesh_Brand_2_Refinement_Challenge_dataset.xlsx - The provided dataset, used by default for train and predict
├── download_models.sh - Downloads the pre-trained models from AWS.
├── models/ - Trained models, optimizer logs and checkpoints.
├── output
│   └── forecast.xlsx - The output of the predict forecast command.
├── optimize.py - Used to optimize the model hyperparameters for a new dataset.
├── predict.py - Used to output or graph the predicted forecast
├── robust
│   └── submissionx.csv - The robustness windows required in spec.
├── robustness.py - This implements the robustness function as required in the challenge spec.
├── REPORT.docx - Information regarding the strategy and ML approach used
└── train.sh - Trains the neural network on a new dataset
```

## Prerequisites
1. Python 3.6
2. PyTorch 1.5 (GPU is not necessary for prediction but recommended for training/optimization)
3. wget (used to download models)

*Note: `wget` is used by the `download_models.sh` script.  If this is not
available, the models can be downloaded from (https://sandesh-3.s3.amazonaws.com/models-4-discovery.zip) manually.*

## Deployment Instructions
```bash
pip3 install -r requirements.txt
# The trained models must be downloaded separately and total around 1.2GB.
./download_models.sh
# This will output the predictions to `output/forecast.xlsx`.
# Note, that this will predict the period of Mar 2020 - Aug 2020 by default.
./predict.py forecast
# To predict the period of Oct 2019 - Mar 2020 run:
./predict.py forecast --skip-last-months=6
# This will graph the actual vs predicted MAPE for the final 6 months in the
# dataset (Oct 2019 - Mar 2020).
./predict.py mape
# This will graph the actual vs predicted RMSE for 12 months of 12 month forecast
# windows.
./robustness.py --graph --no-save
# If only the output of each window is needed, run:
./robustness.py
# These will be outputted in .csv format to the robust/ directory.
```
*Note: All commands accept a `--help` flag which will output all of the options
that they accept.*

## Training on a new Data Set (Optional, GPU Recommended)
*Note: The training command will automatically skip the last 6 months
of the dataset (as this was reserved for MAPE only).  If this is undesirable,
the `--skip-last-months=0` flag can be used.*
```bash
./train.sh /path/to/new-dataset.xlsx
```

## Optimizing Hyperparameters for a new Dataset (Optional, GPU Recommended)
*Note: The optimize command will automatically skip the last 6 months
of the dataset (as this was reserved for MAPE only).  If this is undesirable,
the `--skip-last-months=0` flag can be used.*
This will use a Bayesian optimization routine to iterate through
possible model hyperparameters.  The best parameters are saved to `config.json`
and are used for the `train` command.
```bash
./optimize.sh /path/to/new-dataset.xlsx
```

## Config File Structure
The `config.json` file allows the behavior of the forecast to be customized as follows:
- The `cuda` field may be set to `true` to enable GPU acceleration.  Please ensure that the PyTorch version installed matches the CUDA version of the installed GPU drivers.
- The `dataset` fields can be changed if a new dataset is used that has different variables names, or a different excel file structure:
  - `header_row` - The 0-indexed row number where the date columns are found.
  - `key_column` - The column name for the rows that contain the variable keys.  This is `Generic LookupKey` in the provided dataset.
  - `target_variables` - A list of variable keys for the target variables that should be forecasted.  For this challenge, these keys are:
    1. `Segment 1 - Sandesh Brand 1Sandesh Brand 1MobileLeopardEquipment Revenue`
    2. `Segment 1 - Sandesh Brand 1Sandesh Brand 1MobileLeopardAverage revenue per existing customer (Equipment)`
    3. `Segment 1 - Sandesh Brand 1Sandesh Brand 1MobileLeopardMobile Data Revenue`
    4. `Segment 1 - Sandesh Brand 1Sandesh Brand 1MobilePantherClosing Base`
