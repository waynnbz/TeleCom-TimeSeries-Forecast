#!/usr/bin/env python3
import click
import json
import logging
import numpy as np
import optuna
import os
import pickle

from config import config
from data import load_dataset
from predict import mean_absolute_percentage_error, Pipeline
from train import train_validation_folds

class SaveBestWeights(object):
    def __init__(self, model_dir):
        self.model_dir = model_dir

    def __call__(self, study, trial):
        if trial == study.best_trial:
            print("Saving weights for current best trial:")
            for validation_fold in range(trial.params['validation_splits']):
                source = os.path.join(self.model_dir, "model-ensemble-{}.pkl".format(validation_fold))
                target = os.path.join(self.model_dir, "best-model-ensemble-{}.pkl".format(validation_fold))
                print("Renaming {} to {}".format(source, target))
                os.rename(source, target)

class SaveBest(object):
    """Saves the current best parameters from the trial to the config file."""
    def __init__(self, config_file, name):
        self.config_file = config_file
        self.name = name

    def __call__(self, study, trial):
        try:
            with open(self.config_file, "r") as f:
                config = json.load(f)
        except:
            config = {}

        try:
            config[self.name] = study.best_params

            with open(self.config_file, "w") as f:
                json.dump(config, f, indent=4)
        except:
            pass

class SaveProgress(object):
    """Pickles the current trial state so that it may be resumed in the future."""
    def __init__(self, filename):
        self.filename = filename

    def __call__(self, study, trial):
        with open(self.filename, "wb") as f:
            pickle.dump(study, f)

def calculate_score(dataset_file, work_folder, trial):
    """Calculates the score of the model based on the MAPE and the thresholds
    and targets for each output variable."""

    df = load_dataset(dataset_file)
    pipeline = Pipeline(
        work_folder,
        trial=trial,
        validation_splits=trial.params['validation_splits'],
        window_size=trial.params['window_size'],
    )
    input_df = df.iloc[0:-6]
    results = pipeline.predict(input_df)

    target_variables = config['dataset']['target_variables']

    def get_mape(var):
        y_true = df.iloc[-6:][var].dropna()
        y_pred = results.loc[y_true.index][var]
        return mean_absolute_percentage_error(y_true.to_numpy(), y_pred.to_numpy())

    mapes = [get_mape(var) for var in target_variables]

    score = np.mean(1.0 - np.minimum(mapes, 1.0)) * 0.5

    for target, mape in zip(target_variables, mapes):
        if mape <= config['optimize'][target]['threshold']:
            score = score + 0.03

        if mape <= config['optimize'][target]['target']:
            score = score + 0.03

    return score

def optimize(name, objective, config_file, dataset_file, iterations, resume, work_folder, **kwargs):
    """This handles the flow for the Optuna optimizer.  The best parameters are
    saved to the config file.  The optimizer state is saved after every
    iteration to allow resuming.  The optimizer results are saved to the
    log file."""
    def objective_wrapper(trial):
        mse = objective(
            dataset_file=dataset_file,
            trial=trial,
            **kwargs,
        )

        if np.isnan(mse):
            return np.nan

        return calculate_score(dataset_file, work_folder, trial)

    log_file = os.path.join(work_folder, "{}-opt-log.txt".format(name))
    logging.basicConfig(filename=log_file, format='%(asctime)s %(message)s', level=logging.INFO)
    optuna.logging.enable_propagation()

    resume_file = os.path.join(work_folder, "{}-opt-progress.pkl".format(name))
    if resume:
        print("Resuming optimization from checkpoint")
        with open(resume_file, "rb") as f:
            study = pickle.load(f)
    else:
        study = optuna.create_study(
            direction="maximize",
        )

    study.optimize(
        objective_wrapper,
        catch=(RuntimeError, ValueError),
        callbacks=[SaveBest(config_file, name), SaveBestWeights(work_folder), SaveProgress(resume_file)],
        n_trials=iterations,
        show_progress_bar=False,
    )

    print("Restoring best saved weights:")
    for validation_fold in range(study.best_params["validation_splits"]):
        source = os.path.join(work_folder, "best-model-ensemble-{}.pkl".format(validation_fold))
        target = os.path.join(work_folder, "model-ensemble-{}.pkl".format(validation_fold))
        print("Renaming {} to {}".format(source, target))
        os.rename(source, target)

@click.command()
@click.argument("dataset-file", default="./dataset/Privatized Data for Evaluation.xlsx")
@click.option("--epochs", default=20)
@click.option("--batch-size", default=1)
@click.option("--config-file", default="./config.json")
@click.option("--iterations", default=1000)
@click.option("--patience", default=2)
@click.option("--skip-last-months", default=6)
@click.option("--resume/--no-resume", default=False)
@click.option("--work-folder", default="./models")
def cli(**kwargs):
    print("Optimizing model hyperparameters")
    optimize(
        "model",
        train_validation_folds,
        save_model=True,
        **kwargs,
    )

if __name__ == "__main__":
    cli()
