"""This provides global access to the configuration settings."""
import json

with open("./config.json") as fp:
    config = json.load(fp)
