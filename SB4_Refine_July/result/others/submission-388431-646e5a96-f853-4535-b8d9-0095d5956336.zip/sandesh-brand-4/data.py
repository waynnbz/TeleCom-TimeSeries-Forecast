import datetime
import numpy as np
import os
import pandas as pd
import pickle
import random
import torch
from skimage.util import view_as_windows
from sklearn.model_selection import KFold, TimeSeriesSplit
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from torch.utils.data import Dataset, DataLoader

from config import config

def create_data_generators(
    dataset_file,
    batch_size=1,
    validation_fold=0,
    validation_splits=5,
    validation_type="k-fold",
    shuffle=False,
    skip_last_months=6,
    window_size=12,
    window_step=1,
):
    """Creates Data Generators for the training and validation sets.
    Handles the steps for scaling and preprocessing."""
    dataset = load_dataset(dataset_file)

    # Do not train with data that is reserved for MAPE validation
    if skip_last_months > 0:
        dataset = dataset.iloc[0:-skip_last_months]

    dataset = preprocess(dataset, create=True)

    num_features = dataset.shape[1]

    windows = create_dataset_windows(dataset, window_size, window_step)

    truth_columns = [dataset.columns.get_loc(name) for name in config['dataset']['target_variables']]

    if validation_splits == 1:
        return DataLoader(WindowDataset(windows, truth_columns), batch_size=batch_size, shuffle=shuffle), None, num_features

    k = KFold(n_splits=validation_splits) if validation_type == "k-fold" else TimeSeriesSplit(n_splits=validation_splits)

    training_indices, validation_indices = list(k.split(windows))[validation_fold]

    return (
        DataLoader(WindowDataset(windows[training_indices], truth_columns), batch_size=batch_size, shuffle=shuffle),
        DataLoader(WindowDataset(windows[validation_indices], truth_columns), batch_size=batch_size),
        num_features,
    )

def create_dataset_windows(dataset, window_size, step=1):
    """Splits the dataset into multiple samples, each made from
    a sliding window of the provided size."""
    arr = dataset.to_numpy()
    windows = view_as_windows(arr, (window_size, arr.shape[1]), step)
    return windows.copy().squeeze(axis=1)

def load_dataset(dataset_file):
    """Loads the Excel dataset and then swaps the rows/columns so that the
    memory array matches the input expected by the neural network."""
    df = pd.read_excel(
        dataset_file,
        header=config['dataset']['header_row'],
        index_col=config['dataset']['key_column'],
        na_values=['x'],
        usecols=lambda c: c == config['dataset']['key_column'] or type(c) == datetime.datetime
    )
    df = df.transpose()

    df.loc[:, 'Month'] = df.index.copy().month

    return df.dropna(axis=1, how="all")

def preprocess(df, create=False):
    """Scales the dataset feature-wise to range of [0...1] and then applies
    transformations to minimize skews and trends."""

    # Skip diffing step for month feature
    month = df['Month']
    df = df.diff()
    df.loc[:, 'Month'] = month

    if create:
        pipeline = make_pipeline(
            StandardScaler(),
            MinMaxScaler(),
        )
    else:
        with open("./models/preprocessor.pkl", "rb") as fp:
            pipeline = pickle.load(fp)

    df = df.copy()

    if create:
        df[:] = pipeline.fit_transform(df.to_numpy())
        with open("./models/preprocessor.pkl", "wb") as fp:
            pickle.dump(pipeline, fp)
    else:
        df[:] = pipeline.transform(df.to_numpy())

    return df.fillna(-1)

def inverse_preprocess(df, previous_step):
    """Inverses the preprocessing."""

    with open("./models/preprocessor.pkl", "rb") as fp:
        pipeline = pickle.load(fp)

    df = df.copy()
    df[:] = pipeline.inverse_transform(df.to_numpy())

    df = pd.concat([previous_step.to_frame().transpose(), df])
    df = df.cumsum(skipna=False)

    return df.iloc[1:]

class WindowDataset(Dataset):
    def __init__(
        self,
        dataset_windows,
        truth_columns=[],
    ):
        self.dataset_windows = dataset_windows
        self.truth_columns = truth_columns

    def __len__(self):
        return len(self.dataset_windows)

    def __getitem__(self, idx):
        steps = config['expected_forecasted_months']

        offset = random.randint(1, steps)
        encoder_inputs = self.dataset_windows[idx,steps-offset:-offset]

        targets = self.dataset_windows[...,self.truth_columns]

        decoder_inputs = targets[idx,-3:-1]
        truths = targets[idx,-2:]

        encoder_tensor = torch.from_numpy(encoder_inputs).float()
        decoder_tensor = torch.from_numpy(decoder_inputs).float()
        truth_tensor = torch.from_numpy(truths).float()
        if config['cuda']:
            encoder_tensor = encoder_tensor.cuda()
            decoder_tensor = decoder_tensor.cuda()
            truth_tensor = truth_tensor.cuda()

        return (encoder_tensor, decoder_tensor), truth_tensor
