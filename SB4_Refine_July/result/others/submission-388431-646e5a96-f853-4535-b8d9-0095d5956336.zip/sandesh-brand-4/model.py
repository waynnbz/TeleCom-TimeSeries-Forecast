import math
import numpy as np
import torch
from optuna.trial import FixedTrial
from poutyne.framework import Model
from torch.nn import Dropout, Module, Linear, Transformer
from torch.nn.functional import relu

from config import config

ATTENTION_HEADS = [2, 4, 8, 16, 32, 64]
EMBEDDING_SIZES = [64, 128, 256, 512, 1024]
FEEDFORWARD_SIZES = [64, 128, 256, 512, 1024, 2048, 4096]

class PositionalEncoding(Module):
    """Adapted from https://pytorch.org/tutorials/beginner/transformer_tutorial.html"""
    def __init__(self, d_model, seq_length, dropout=0.1):
        super(PositionalEncoding, self).__init__()
        self.dropout = Dropout(p=dropout)

        pe = torch.zeros(seq_length, d_model)
        position = torch.arange(0, seq_length, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

class ForecastModule(Module):
    def __init__(self, trial, input_features, window_size):
        super(ForecastModule, self).__init__()

        output_features = len(config['dataset']['target_variables'])
        embedding_size = trial.suggest_categorical("embedding_size", EMBEDDING_SIZES)

        self.encoder_scale = math.sqrt(embedding_size)

        self.encoder_embedding = Linear(in_features=input_features, out_features=embedding_size)
        self.decoder_embedding = Linear(in_features=output_features, out_features=embedding_size)

        self.pos_encoder = PositionalEncoding(embedding_size, window_size - 1)

        self.transformer = Transformer(
            activation=trial.suggest_categorical("activation", ["gelu", "relu"]),
            d_model=embedding_size,
            dropout=trial.suggest_uniform("dropout", 0.0, 1.0),
            nhead=trial.suggest_categorical("attention_heads", ATTENTION_HEADS),
            num_encoder_layers=trial.suggest_int("encoder_layers", 1, 12),
            num_decoder_layers=trial.suggest_int("decoder_layers", 1, 12),
            dim_feedforward=trial.suggest_categorical("feedforward_dimension", FEEDFORWARD_SIZES),
        )

        self.output = Linear(in_features=embedding_size, out_features=output_features)

    def forward(self, encoder_inputs, decoder_inputs):
        encoder_in = self.encoder_embedding(encoder_inputs)
        decoder_in = self.decoder_embedding(decoder_inputs)

        encoder_in = relu(encoder_in)
        decoder_in = relu(decoder_in)

        encoder_in = encoder_in.transpose(0, 1)
        decoder_in = decoder_in.transpose(0, 1)

        encoder_in = encoder_in * self.encoder_scale

        encoder_in = self.pos_encoder(encoder_in)

        transformer_out = self.transformer(encoder_in, decoder_in)

        transformer_out = transformer_out.transpose(0, 1)

        return self.output(transformer_out)

def get_model(input_features, window_size, loss=None, metric=None, opt=None, trial=None):
    if trial is None:
        trial = FixedTrial(config['model'])

    module = ForecastModule(trial, input_features, window_size)

    if config['cuda']:
        module.cuda()

    model = Model(
        module,
        batch_metrics=[metric] if metric else None,
        optimizer=opt(module) if opt is not None else None,
        loss_function=loss,
    )

    return model
