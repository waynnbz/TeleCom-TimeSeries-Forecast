#!/usr/bin/env python3
import click
import gc
import json
import numpy as np
import os
from optuna.trial import FixedTrial
from poutyne.framework.callbacks import EarlyStopping, ModelCheckpoint, TerminateOnNaN
from poutyne.framework.callbacks.lr_scheduler import ReduceLROnPlateau
from pprint import pprint
from torch.optim import Adam, Adadelta, RMSprop, SGD

from config import config
from data import create_data_generators
from model import get_model

def build_callbacks(filename=None, mode="min", monitor="mse", patience=3, plateau=None, trial=None, validation=False):
    """Creates a set of training callbacks to terminate the training if an
    error occurs.  To adjust the training parameters if the results are
    not improving, and to save the best performing epochs of the model."""
    if validation:
        monitor = "val_" + monitor

    callbacks = [TerminateOnNaN()]

    if patience > 0:
        callbacks.append(EarlyStopping(mode=mode, monitor=monitor, patience=patience, verbose=True))

    if filename is not None:
        callbacks.append(ModelCheckpoint(filename, mode=mode, monitor=monitor, save_best_only=True, verbose=True))

    if plateau is not None:
        callbacks.append(ReduceLROnPlateau(mode=mode, monitor=monitor, factor=0.2, patience=plateau, verbose=True))

    return callbacks

def get_optimizer(trial):
    """Creates a training optimizer based on the suggested name/lr."""
    name = trial.suggest_categorical("optimizer", ["adam", "adadelta", "rmsprop", "sgd"])
    lr = trial.suggest_loguniform("learning_rate", 1e-8, 1e-1)

    if name == "adam":
        return lambda module: Adam(module.parameters(), lr=lr)
    elif name == "adadelta":
        return lambda module: Adadelta(module.parameters(), lr=lr)
    elif name == "rmsprop":
        return lambda module: RMSprop(module.parameters(), lr=lr)
    elif name == "sgd":
        return lambda module: SGD(module.parameters(), lr=lr, momentum=0.9, nesterov=True)

def train_model(
    dataset_file="./dataset/Privatized Data for Evaluation.xlsx",
    batch_size=8,
    epochs=20,
    validation_fold=0,
    model_file="./models/model.h5",
    patience=3,
    plateau=None,
    prune=False,
    shuffle=False,
    skip_last_months=6,
    trial=None,
    validation_splits=1,
    **kwargs,
):
    """Handles the Keras training flow, including instantiating the
    training/validation data generators.  Creating and training the model,
    and also returns the score of the best epoch for optimization purposes."""

    window_size = trial.suggest_int("window_size", 12, 42)

    training_datagen, validation_datagen, num_features = create_data_generators(
        dataset_file,
        batch_size=batch_size,
        validation_fold=validation_fold,
        validation_splits=validation_splits,
        validation_type=trial.suggest_categorical("validation_type", ["k-fold", "time-series"]),
        skip_last_months=skip_last_months,
        shuffle=shuffle,
        window_size=window_size,
    )

    opt = get_optimizer(trial)

    metric = "mse"

    model = get_model(
        num_features,
        trial=trial,
        opt=opt,
        loss=trial.suggest_categorical("loss_function", ["l1", "mse", "smooth_l1"]),
        metric=metric,
        window_size=window_size,
    )


    results = model.fit_generator(
        training_datagen,
        callbacks=build_callbacks(model_file, monitor=metric, patience=patience, plateau=plateau, validation=validation_datagen),
        epochs=epochs,
        valid_generator=validation_datagen,
    )

    return np.nanmin([epoch[('val_' + metric) if validation_datagen else metric] for epoch in results])

def train_validation_folds(save_model=True, trial=None, **kwargs):
    scores = []
    validation_splits = trial.suggest_int("validation_splits", 1, 5)
    for validation_fold in range(validation_splits):
        print("\nTraining validation fold {}/{}".format(validation_fold + 1, validation_splits))
        score = train_model(
            validation_fold=validation_fold,
            validation_splits=validation_splits,
            model_file="./models/model-ensemble-{}.pkl".format(validation_fold) if save_model else None,
            trial=trial,
            **kwargs,
        )
        if np.isnan(score):
            return np.nan
        scores.append(score)

    return np.mean(np.array(scores))

@click.command()
@click.argument("dataset-file", default="./dataset/Privatized Data for Evaluation.xlsx")
@click.option("--batch-size", default=1)
@click.option("--epochs", default=500)
@click.option("--patience", default=100)
@click.option("--plateau", default=20)
@click.option("--shuffle/--no-shuffle", default=True)
@click.option("--skip-last-months", default=6)
def train(**kwargs):
    """This loads the optimized hyperparameters from the config file
    and runs a full training suite on each k-fold."""
    params = config['model']

    print("Training Model with parameters:")
    pprint(params, indent=4)

    score = train_validation_folds(
        trial=FixedTrial(params),
        **kwargs,
    )

    print("Training finished with MSE: {}".format(score))

if __name__ == "__main__":
    train()
