# CFO Forecasting - Financial Forecast BB Sandesh Brand 4 - Refinement
#### Approach and Details Report

## Approach
The solution implemented in this submission uses an ensemble of attention-based
Transformer neural networks to forecast the key parameters.

This was chosen as it is a flexible approach that can accommodate additional
key variables and also correlate additional data points with the key variables
in any future data sets.

The preprocessing and training parameters are fully configurable using the
`config.json` file.  These parameters have been optimized for the current
dataset and the thresholds/targets.  These configuations can be updated using
the provided Bayesian optimizer (`optimize.py`) if a new dataset is used.

## Outlier Treatment
The dataset is pre-processed using a diffing technique.  The value of each
variable at every month is replaced with its increase or decrease over the
previous month's value.

This ensures that the neural network is learning the patterns of change between
months, rather than the exact values.  This makes the outliers in the data less
impactful because the spike in change only affects a single month and does not
affect subsequent months, as the trend/base value is removed during the diffing
process.

The prediction module automatically performs the diffing process on the input
data and inverses it using the predictions of the neural network and the last
known original values of the key variables.

## Data Analysis
The dataset is split into overlapping windows, each with a size set by the
`window_size` hyperparameter.  The last month in the window is used as the
sample truth.

In order to utilize as much of the dataset for training as possible, and to
minimize the risk of over-fitting, a k-fold data splitting approach is used.

The number of k-fold sets is configurable, and is set using the
`validation_splits` configuration variable.

Because the sample size is low, the variance of the training process is high.
Models trained using identical hyperparameters and training data show
significant variation.

To address this, an ensembling technique is used where the outputs of the
trained models are averaged for each prediction.

Each model is trained on one of the k-fold data+validation sets.  This
ensures that every data point is used by at least one of the ensembled models.

The input data is also scaled feature-wise so that each value falls between
`0` and `1`.  This isn't strictly necessary with the privatized data, as it
has already been standardized.  However, this does allow the submission to
function correctly if it is used on non-privatized data in the future.

## Model Details
The neural network uses a `seq2seq` architecture with a flexible structure that
is generated based on the hyperparameters saved to the configuration file.

This allows the optimizer to explore many different variables, including the
width and depth of the encoder/decoder, and layer dropout (this helps to
address the limited size of the dataset specifically.)

The supplied hyperparameters were optimized using the Bayesian optimizer
implemented in `optimize.py`.

These can be updated when a new dataset is used to ensure that the best
structure is used for a given set of key variables and forecast windows.

This architecture forecasts a single month per prediction.  The prediction
pipeline can be called with the desired number of months to be predicted
(default 6).  This will run the prediction routine 6 times, and the previous
predictions will be used as an input to each successive prediction.  This allows
the network to predict an arbitrary number of months in the future.

During training, a teacher-forcing approach is used, where the ground truth
data is used as an input for each prediction.

## MAPE
The model is trained in separate steps, each with a k-fold section of the data
windows.  This means that a portion of the dataset is used for validation during
each training iteration, and each of the model ensembles is validated using
a different non-overlapping section of the dataset.

During prediction, the output of all the models is averaged.

_The last 6 months of the dataset (Oct 2019 - Mar 2020) is not used during
training.  This means that the trained neural network has not
been exposed to these months, and has not memorized any of the values._

This is the accuracy results for the last 6 months of provided data:

![MAPE Graph](mape.png)

## Robustness
The `robustness.py` module provides both an importable robustness function
which will calculate the robustness for a given number of months and
iterations and a command-line interface which can render a graph based on this
data.

By default, this generates 12 robustness iterations, each with 12 month windows.
These can be adjusted separately using the command-line options.

This is the graph generated using the provided pre-trained model and original
dataset:

![Robustness Graph](robustness.png)
