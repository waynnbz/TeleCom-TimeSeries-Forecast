#!/usr/bin/env bash

echo "Downloading the trained submission models."
wget "https://sandesh-3.s3.amazonaws.com/models-bb-4-refinement.zip"
unzip "models-bb-4-refinement.zip"
