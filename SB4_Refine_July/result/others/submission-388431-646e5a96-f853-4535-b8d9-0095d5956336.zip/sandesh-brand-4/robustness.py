#!/usr/bin/env python3
import click
import math
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
from datetime import datetime, timedelta
from sklearn.metrics import mean_squared_error

from config import config
from data import create_dataset_windows, load_dataset
from predict import Pipeline

DATE_FORMAT = "%B%Y" # Example: August2020

def robustness(
    end_date=None,
    input_file="./dataset/Privatized Data for Evaluation.xlsx",
    iterations=12,
    model_dir="./models",
    months=12,
    output_dir="./robust",
    save=True,
    start_date=None,
    verbose=True,
):
    """Creates x forecasts using a sliding window of the last x months using
    the last month as the forecast end-date."""
    df = load_dataset(input_file)

    # If end_date is supplied, filter out any dates occuring after this date
    if end_date is not None:
        end_datetime = datetime.strptime(end_date, DATE_FORMAT)
        df = df[df.index <= end_datetime]

        # If start_date is also supplied, use this to override the default
        # number of months.
        if start_date is not None:
            start_datetime = datetime.strptime(start_date, DATE_FORMAT)
            months = math.ceil((end_datetime - start_datetime).days / 30)
    else:
        # If only start_date is provided, infer the end_date from this
        # and the months argument.
        if start_date is not None:
            start_datetime = datetime.strptime(start_date, DATE_FORMAT)
            end_datetime = start_datetime + timedelta(days=months * 31)
            df = df[df.index <= end_datetime]

    if verbose:
        print("Generating robustness prediction files")

    pipeline = Pipeline(model_dir)

    target_variables = config['dataset']['target_variables']
    window_size = config['model']['window_size'] + months

    # Depending on the window_size hyperparameter, there may not be enough
    # historical data to create windows going back x months.
    # Zero pad the dataframe to ensure that the array always has the expected
    # shape for a given number of months and window size.
    pad_size = (window_size + iterations) - df.shape[0]
    if pad_size > 0:
        df = pd.DataFrame(np.full((pad_size, df.shape[1]), np.nan), columns=df.columns).append(df)

    windows = create_dataset_windows(df, window_size)[-iterations:]
    results_windows = []
    # Iterate through each window and create an indexed dataframe for its data.
    # Each frame will have this layout in memory:
    # |window_size for neural network input|forecasted months actual|
    # This needs to be split into the separate input and actual segments.
    for i, data_window in enumerate(windows):
        j = len(windows) - i
        if verbose:
            print("\nPredicting iteration {}".format(j))
        inv_i = (iterations - i) - 1
        window_df = pd.DataFrame(data_window, columns=df.columns, index=df.iloc[-(window_size + inv_i):-inv_i if inv_i else None].index)
        # This is the actual section, which will be saved for the RMSE calculation
        truth_df = window_df.iloc[-months:]
        # This is the input section that will be passed to the neural network
        input_df = window_df.iloc[:-months]
        results = pipeline.predict(input_df, months)

        if save:
            output_df = results[target_variables]
            output_df.index.name = "Time Period"
            output_df.to_csv(os.path.join(output_dir, "submission{}.csv".format(j)))
        # Save the actual/forecast pair to allow the RMSE to be calculated later
        results_windows.append((truth_df, results))

    return list(reversed(results_windows))

@click.command()
@click.argument("input-file", default="./dataset/Privatized Data for Evaluation.xlsx")
@click.option("--end-date", default=None, type=click.STRING)
@click.option("--figure-size", default=12)
@click.option("--graph/--no-graph", default=False)
@click.option("--iterations", default=12)
@click.option("--model-dir", default="./models")
@click.option("--months", default=12)
@click.option("--output-windows/--no-output-windows", default=False)
@click.option("--save/--no-save", default=True)
@click.option("--start-date", default=None, type=click.STRING)
@click.option("--ylim", default=6)
def cli(
    figure_size,
    input_file,
    graph,
    iterations,
    model_dir,
    months,
    output_windows,
    save,
    ylim,
    **kwargs,
):
    """Creates x forecasts using a sliding window of the last x months using
    the last month as the forecast end-date.  Calculates the RMSE against
    the actual values from the dataset and plots these on a graph for each
    target variable."""
    results_windows = robustness(
        input_file=input_file,
        iterations=iterations,
        model_dir=model_dir,
        months=months,
        save=save,
        **kwargs,
    )

    if graph:
        target_variables = config['dataset']['target_variables']
        plt.figure(figsize=(figure_size, figure_size))
        for j, var in enumerate(target_variables):
            plt.subplot(len(target_variables), 1, j + 1)
            plt.tight_layout()
            plt.title(var)

            # Calculate the RMSE of the feature using the actual/forecast pair
            rmse_arr = np.array([mean_squared_error(y_true[var].dropna().to_numpy(), y_pred[var].loc[y_true[var].dropna().index].to_numpy(), squared=False) for y_true, y_pred in results_windows])
            # Label and plot the RMSE of each window as [1..n]
            index = [k + 1 for k in range(months)]
            rmse_df = pd.Series(rmse_arr, index=index)
            rmse_df.plot(ylim=[0, ylim], xticks=index)

            # Render the actual RMSE values at each point
            for l, rmse in enumerate(rmse_arr):
                plt.text(l + 0.9, rmse + (ylim * 0.1), "{:.3f}".format(rmse))

            plt.legend(["RMSE"])

        plt.show()

if __name__ == "__main__":
    cli()
