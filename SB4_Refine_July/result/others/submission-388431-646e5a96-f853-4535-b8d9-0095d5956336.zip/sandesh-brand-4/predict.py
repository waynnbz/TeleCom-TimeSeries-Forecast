#!/usr/bin/env python3
import click
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import torch
from pprint import pprint

from config import config
from data import create_dataset_windows, load_dataset, preprocess, inverse_preprocess
from model import get_model

def mean_absolute_percentage_error(y_true, y_pred):
    """Calculates the MAPE for the provided actual and predicted vectors."""
    return np.mean(np.abs((y_true - y_pred) / y_true))

class Pipeline:
    """This class handles the entire prediction flow, including
    pre/post processing and scaling."""
    def __init__(
        self,
        model_dir,
        trial=None,
        validation_splits=config['model']['validation_splits'],
        window_size=config['model']['window_size'],
    ):
        self.validation_splits = validation_splits
        self.model_dir = model_dir
        self.trial = trial
        self.window_size = window_size

    def predict(self, dataset, steps=6):
        target_variables = config['dataset']['target_variables']

        input_df = preprocess(dataset)

        encoder_input = input_df.to_numpy()
        encoder_input = np.expand_dims(encoder_input[-(self.window_size - config['expected_forecasted_months']):], 0)

        decoder_input = input_df[target_variables].to_numpy()
        decoder_input = np.expand_dims(decoder_input[-2:], 0)

        model = get_model(encoder_input.shape[-1], self.window_size, trial=self.trial)

        predictions = []
        for i in range(steps):
            print("Predicting Month t+{}".format(i + 1))
            ensemble_predictions = []
            for validation_fold in range(self.validation_splits):
                print("Predicting with ensemble model {}/{}".format(validation_fold + 1, self.validation_splits))
                fullpath = os.path.join(self.model_dir, "model-ensemble-{}.pkl".format(validation_fold))
                model.load_weights(fullpath)

                encoder_tensor = torch.from_numpy(encoder_input).float()
                decoder_tensor = torch.from_numpy(decoder_input).float()
                if config['cuda']:
                    encoder_tensor = encoder_tensor.cuda()
                    decoder_tensor = decoder_tensor.cuda()

                (prediction,) = model.predict((encoder_tensor, decoder_tensor), batch_size=1)
                ensemble_predictions.append(prediction[-1])

            prediction_average = np.mean(np.array(ensemble_predictions), axis=0)

            decoder_input = np.roll(decoder_input, -1, axis=1)
            decoder_input[:,-1] = prediction_average

            predictions.append(prediction_average)

        # Generate a month label for each of the predictions and assign them to the df index
        months = pd.date_range(dataset.index[-1], freq='MS', periods=steps + 1)
        prediction_df = pd.DataFrame(np.array(predictions), columns=target_variables, index=months[1:])

        results = dataset.append(prediction_df)

        results = inverse_preprocess(results.iloc[-steps:], dataset.iloc[-1])

        return results

@click.group()
def cli():
    pass

@cli.command()
@click.argument("input-file", default="./dataset/Privatized Data for Evaluation.xlsx")
@click.argument("output-file", default="./output/forecast.xlsx")
@click.option("--model-dir", default="./models")
@click.option("--months", default=6)
@click.option("--skip-last-months", default=0)
def forecast(
    input_file,
    months,
    output_file,
    skip_last_months,
    **kwargs,
):
    """This creates a copy of the input dataset with the 'x' columns
    filled in using the trained neural network."""
    dataset = load_dataset(input_file)

    if skip_last_months > 0:
        dataset = dataset.iloc[0:-skip_last_months]

    pipeline = Pipeline(**kwargs)

    print("Outputting forecast to {}".format(output_file))

    results = pipeline.predict(dataset, months)

    writer = pd.ExcelWriter(
        output_file,
        engine='xlsxwriter',
        datetime_format='yyyy-mm',
        date_format='yyyy-mm-yy',
    )

    results.transpose().to_excel(writer)

    # Set the column widths to allow the full text to be shown
    writer.sheets['Sheet1'].set_column('A:A', 120)
    writer.sheets['Sheet1'].set_column('B:AK', 12)

    writer.save()

@cli.command("mape")
@click.argument("input-file", default="./dataset/Privatized Data for Evaluation.xlsx")
@click.option("--figure-size", default=12)
@click.option("--model-dir", default="./models")
@click.option("--ylim", default=3)
def graph_mape(
    figure_size,
    input_file,
    ylim,
    **kwargs,
):
    """Predicts the values of the last 6 month period in the dataset
    and compares with actual values.  This can also plot the future 6 month
    prediction for visual assessment."""
    df = load_dataset(input_file)

    pipeline = Pipeline(**kwargs)
    input_df = df.iloc[0:-6]
    results = pipeline.predict(input_df)

    target_variables = config['dataset']['target_variables']

    plt.figure(figsize=(figure_size,figure_size))
    for i, var in enumerate(target_variables):
        plt.subplot(len(target_variables), 1, i + 1)
        plt.tight_layout()

        y_true = df.iloc[-6:][var].dropna()
        y_pred = results.loc[y_true.index][var]
        mape = mean_absolute_percentage_error(y_true.to_numpy(), y_pred.to_numpy())
        plt.title("{}\nMAPE: {:.2f}%".format(var, mape * 100))

        df.iloc[-6:][var].plot(ylim=[-ylim, ylim])
        results.iloc[-6:][var].plot(ylim=[-ylim, ylim])
        plt.legend(["Actual", "Predicted"])

    def mape(var):
        y_true = df.iloc[-6:][var].dropna()
        y_pred = results.loc[y_true.index][var]
        return mean_absolute_percentage_error(y_true.to_numpy(), y_pred.to_numpy())

    mapes = [mape(var) for var in target_variables]

    print(np.mean(mapes))

    plt.show()

if __name__ == "__main__":
    cli()
